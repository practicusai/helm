# Nod namespace defined? default to prt-ns
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
fi

# Starting
clear
echo "Installing Istio"
echo "Check latest info from: https://istio.io/latest/docs/setup/platform-setup/openshift/"
echo ""

oc adm policy add-scc-to-group anyuid system:serviceaccounts:istio-system
istioctl install --set profile=openshift -y
oc -n istio-system expose svc/istio-ingressgateway --port=http2
