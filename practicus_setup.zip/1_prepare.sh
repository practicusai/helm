# Helpers
GREEN='\033[0;92m' && RED='\033[0;91m' && NO_COLOR='\033[0m'
function fail {
    printf "${RED}ERROR: %s\n\n" "$1" >&2
    exit 1
}

if [[ -z "$PRT_CERT_CN" ]]; then
    fail "Please define the certificates common name using: 'export PRT_CERT_CN=*.company.com'"
    exit 1
fi

# Starting
clear
echo "Preparing to setup Practicus AI Kubernetes backend"
echo ""
echo "DNS for the service         : ${GREEN} $PRT_CERT_CN ${NO_COLOR}"
echo "Directory to write files to : ${GREEN} $PWD ${NO_COLOR}"
echo ""
echo "Please ${GREEN} hit enter to confirm ${NO_COLOR} or ${RED} CTRL+C to quit. ${NO_COLOR}"
read -r

rm -rf secrets
mkdir secrets

echo "Current system Python version is:"
python3 --version || fail "Python3 not found, please install python first. Exiting script."

echo "Creating a temporary Python virtual environment for libraries needed during setup"
python3 -m venv ./venv

echo "Installing supporting security libraries"
./venv/bin/python3 -m pip install --upgrade pip
./venv/bin/python3 -m pip install jwcrypto

echo "Creating additional certificates for JWT and mutual TLS inside kubernetes cluster"
openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout ./secrets/jwt_private.pem -subj "/CN=$PRT_CERT_CN" > ./secrets/openssl.msg.txt

openssl rsa -in ./secrets/jwt_private.pem \
  -outform PEM -pubout -out ./secrets/jwt_public.pem > ./secrets/openssl.msg.txt

openssl req -x509 -newkey rsa:4096 -sha256 -days 3650 -nodes \
  -keyout ./secrets/istio_mtls_key.pem -out ./secrets/istio_mtls_cert.pem -subj "/CN=$PRT_CERT_CN"

echo "Creating other secrets"
./venv/bin/python3 helper.py

echo "Adding practicusai helm repo"
helm repo add practicusai https://practicusai.github.io/helm

echo "Updating all helm repos on your computer"
helm repo update

# You can view available charts in practicusai repo using the below.
# helm search repo practicusai

