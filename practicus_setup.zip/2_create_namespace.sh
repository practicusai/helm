# No namespace defined? default to prt-ns
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
fi

# Starting
clear
echo "Creating kubernetes namespace."
current_kubectl_context=$(kubectl config current-context)
echo "Current kubectl context : $current_kubectl_context"
echo ""

kubectl create namespace $PRT_NS
