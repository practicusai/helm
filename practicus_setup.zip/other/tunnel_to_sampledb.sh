#!/bin/bash

echo " ** Creating temp tunnel to sample database **"
SAMPLEDB_POD_NAME=$(kubectl -n prt-ns get pod -l \
  app=postgresdb -o jsonpath="{.items[0].metadata.name}")
echo "Sample db pod name is: $SAMPLEDB_POD_NAME"

echo "Starting temporary connection tunnel"
kubectl -n prt-ns port-forward "$SAMPLEDB_POD_NAME" 5432:5432
