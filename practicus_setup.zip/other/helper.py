import base64
import os
import sys
from pathlib import Path
from typing import Tuple
from uuid import uuid4


def get_pem_base64(pem_path: str) -> Tuple[bytes, str]:
    if not os.path.exists(pem_path):
        print(f"Error: {pem_path} file doesn't exist. Please generate openssl keys first",
              file=sys.stderr)
        exit(1)
    with open(pem_path, "rt") as f:
        pem_data = f.read()
    pem_data_encoded = pem_data.encode("utf-8")
    pem_data_str = str(base64.b64encode(pem_data_encoded), "utf-8")
    return pem_data_encoded, pem_data_str


if __name__ == '__main__':
    try:
        from jwcrypto import jwt, jwk
    except:
        print("Could not import jwcrypto library. Please install using the below", file=sys.stderr)
        print("pip3 install jwcrypto")
        exit(1)

    working_dir = Path(os.path.dirname(__file__)).parent
    secrets_dir = os.path.join(working_dir, "secrets")

    jwt_private_pem_path = os.path.join(secrets_dir, "jwt_private.pem")
    private_pem_data_encoded, private_pem_data_encoded_str = get_pem_base64(jwt_private_pem_path)

    jwt_public_pem_path = os.path.join(secrets_dir, "jwt_public.pem")
    _, public_pem_data_encoded_str = get_pem_base64(jwt_public_pem_path)

    istio_mtls_key_pem_path = os.path.join(secrets_dir, "istio_mtls_key.pem")
    _, istio_mtls_key_pem_data_encoded_str = get_pem_base64(istio_mtls_key_pem_path)

    istio_mtls_cert_pem_path = os.path.join(secrets_dir, "istio_mtls_cert.pem")
    _, istio_mtls_cert_pem_data_encoded_str = get_pem_base64(istio_mtls_cert_pem_path)

    web_hash_salt_path = os.path.join(secrets_dir, "web_hash_salt.txt")
    web_hash_salt = f"{uuid4().hex}{uuid4().hex}"
    with open(web_hash_salt_path, "wt") as f:
        f.write(web_hash_salt)

    jwt_key = jwk.JWK.from_pem(private_pem_data_encoded)

    jwks_json = "{ \"keys\":[ " + jwt_key.export(private_key=False) + "]}"
    with open(os.path.join(secrets_dir, "jwks.json"), "wt") as f:
        f.write(jwks_json)

    print(f"Secret files are generated and written under: {secrets_dir}")

    values_yaml_path = os.path.join(working_dir, "values-keys.yaml")
    with open(values_yaml_path, "wt") as f:
        jwt_yaml = f"# You can update this file and the generated keys manually or by running the helper scripts\n\n" \
                   f"jwt:\n" \
                   f"  privateKeyBase64: {private_pem_data_encoded_str}\n" \
                   f"  publicKeyBase64: {public_pem_data_encoded_str}\n" \
                   f"  jwks: '{jwks_json}'\n\n"
        f.write(jwt_yaml)

        istio_yaml = f"istio:\n" \
                     f"  mtlsKeyBase64: {istio_mtls_key_pem_data_encoded_str}\n" \
                     f"  mtlsCertBase64: {istio_mtls_cert_pem_data_encoded_str}\n\n"
        f.write(istio_yaml)

        web_hash_salt_b64 = str(base64.b64encode(bytes(web_hash_salt, "utf-8")), "utf-8")
        web_hash_salt_yaml = f"session:\n" \
                             f"  webHashSaltBase64: {web_hash_salt_b64}\n"
        f.write(web_hash_salt_yaml)

    print(f"Secret values yaml file is generated and written to {values_yaml_path}")
