#!/bin/bash

echo "THIS SCRIPT IS REQUIRED ONLY IF YOU DISABLED DB AUTO MIGRATION"

echo ""
echo "Checking Practicus AI Management Database configuration status"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "Please hit enter to start viewing database configuration logs."
echo "Verify there are no errors in the logs and then hit Ctrl+C to stop monitoring"
read -r

echo "DB migration pod status"
echo "-----------------------"
kubectl get pod -n $PRT_NS | grep prt-pod-migrate-db
echo ""
echo "Pod logs"
echo "--------"
kubectl logs --follow prt-pod-migrate-db -n $PRT_NS

echo ""