clear

echo " ** Creating temp tunnel to sample object store **"
echo ""
echo "IMPORTANT NOTES:"
echo "* REFRESH browser after temp connection tunnel is opened below"
echo "* User name & password for minio console is both: minioadmin"
echo "* S3 endpoint to use with Practicus AI app is: http://prt-svc-sampleobj.prt-ns.svc.cluster.local"
echo "Opening sample object store in browser: http://127.0.0.1:9090"
open "http://127.0.0.1:9090"
echo ""

SAMPLEOBJ_POD_NAME=$(kubectl -n prt-ns get pod -l \
  app=minio -o jsonpath="{.items[0].metadata.name}")
echo "Sample object store pod name is: $SAMPLEOBJ_POD_NAME"

echo "Starting temporary connection tunnel"
kubectl -n prt-ns port-forward "$SAMPLEOBJ_POD_NAME" 9090:9090
