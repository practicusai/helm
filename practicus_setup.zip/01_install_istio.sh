#!/bin/bash

echo ""
echo "Installing Istio"
istioctl install --set profile=default -y

echo ""