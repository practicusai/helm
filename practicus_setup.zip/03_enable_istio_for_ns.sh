##!/bin/bash
#
#echo ""
#
#if [[ -z "$PRT_NS" ]]; then
#    export PRT_NS=prt-ns
#    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
#fi
#
#echo "Enabling Istio for namespace $PRT_NS"
#echo ""
#
#echo "Injecting istio label for namespace"
#kubectl label namespace $PRT_NS istio-injection=enabled
#
#echo ""
