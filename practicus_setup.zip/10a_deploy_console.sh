#!/bin/bash

echo ""
echo "Installing Practicus AI Management Console"

if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

helm install practicus-console practicusai-dev/practicus-console \
  --namespace $PRT_NS \
  --values values-keys.yaml \
  --values values.yaml

echo ""
