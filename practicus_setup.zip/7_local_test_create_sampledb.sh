echo ""
echo "Creating sample Practicus AI Management Database"

echo "** IMPORTANT ** Sample databases should only be used for testing or PoC scenarios"
echo "Please hit enter to confirm this db will *NOT* be used for production purposes"
read -r

if [[ -z "$PRT_TEST_NS" ]]; then
    export PRT_TEST_NS=prt-ns
    echo "PRT_TEST_NS env variable is not defined, will use the default $PRT_TEST_NS"
fi

kubectl create namespace $PRT_TEST_NS || echo "$PRT_TEST_NS already exists"

helm install practicus-sampledb practicusai/practicus-sampledb --namespace $PRT_TEST_NS
