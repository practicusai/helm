echo ""
echo "Required for Production only - Saving ./secrets contents to values-keys.yaml"
echo "You can skip for local test installation and use the default keys."

echo "Current system Python version is:"
python3 --version || fail "Python3 not found, please install python first. Exiting script."

echo "Creating a temporary Python virtual environment for libraries needed during setup"
python3 -m venv ./venv

echo "Installing supporting security libraries"
./venv/bin/python3 -m pip install --upgrade pip
./venv/bin/python3 -m pip install jwcrypto

echo ""
echo "Saving contents of ./secrets to values-keys.yaml"
./venv/bin/python3 other/helper.py
