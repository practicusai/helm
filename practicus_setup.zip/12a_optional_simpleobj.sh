#!/bin/bash

echo ""
echo "Creating sample S3 compatible Object Storage"

echo "** IMPORTANT ** Simple object storage should only be used for testing or PoC scenarios"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

kubectl create namespace "$PRT_NS" || echo "$PRT_NS already exists"

helm install practicus-simpleobj practicusai/practicus-simpleobj \
  --namespace "$PRT_NS" \
  --values values-simpleobj.yaml

echo ""
echo "Waiting until pods are ready in $PRT_NS namespace"

kubectl wait --for=condition=ready --timeout=60s pod --all -n "$PRT_NS"

echo ""
