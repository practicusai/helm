#!/bin/bash

clear

cd "$(dirname "$0")" || exit

echo "** Preparing for BETA version - Only use for dev/test scenarios! **"
echo
echo "You are installing a beta release *NOT* ideal for production!"
echo "Please hit enter to confirm or CTRL+C to quit."
read -r

echo ""
echo "Adding practicusai-dev helm repo - BETA VERSION"
helm repo add practicusai-dev https://practicusai.github.io/helm/dev || echo " - Practicus AI helm repo already added"

echo "Updating all helm repos on your computer"
helm repo update

rm -rf "practicusai/*" || echo " - No current helm files to delete, all good."

mkdir practicusai || echo "practicusai folder exists"
cd practicusai || exit

echo "Pulling helm chart"
helm pull "practicusai-dev/practicus-console" --untar
helm pull "practicusai-dev/practicus-pg-db" --untar
helm pull "practicusai-dev/rabbitmq" --untar
helm pull "practicusai-dev/rustfs" --untar
cd ..

echo "Copying default values.yaml as values-chart.yaml"
cp "./practicus-console/values.yaml" ./values-chart.yaml

echo ""
echo "Completed preparing"
echo "You can view available charts in practicusai repo running the below:"
echo "helm search repo practicusai-dev"
echo ""

echo ""
echo "Important! Please verify current kubectl context before installing."
current_kubectl_context=$(kubectl config current-context)
echo "Current kubernetes context: $current_kubectl_context"

echo ""