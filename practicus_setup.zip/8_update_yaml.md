# Updating values.yaml 

- Please choose one of the values-local-test.yaml, values-prod.yaml etc. files, rename to values.yaml and update accordingly with your database and other settings. 
- Please check http://docs.practicus.ai/k8s-setup/ if you need help with values.yaml file settings.
- In order to update values-keys.yaml, you can use the supporting create certs script in this directory, or you can update them manually as well. 
