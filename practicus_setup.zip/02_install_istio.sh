#!/bin/bash

if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo ""
echo "Installing Istio"
istioctl install --set profile=default -y

echo "Disable istio Auto sidecar injection"
echo "(Istio workloads  will explicitly enable injection)"
kubectl label namespace prt-ns istio-injection=disabled

echo "Analyzing Istio"
istioctl analyze -n "$PRT_NS"

echo ""