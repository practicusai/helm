echo ""
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo""
echo "Analyzing namespace $PRT_NS for istio issues"
istioctl analyze -n $PRT_NS

ISTIO_INGRESS_HOST=$(kubectl -n istio-system get ingress istio-system -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
ISTIO_INGRESS_IP=$(kubectl -n istio-system get ingress istio-system -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
ISTIO_SERVICE_LB_HOST=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
ISTIO_SERVICE_LB_IP=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

export ISTIO_INGRESS_HOST
export ISTIO_INGRESS_IP
export ISTIO_SERVICE_LB_HOST
export ISTIO_SERVICE_LB_IP

echo ""
echo "You can define a DNS CNAME e.g. for practicus.company.com using the below hosts"
echo " Istio ingress host (preferred): $ISTIO_INGRESS_HOST"
echo " Istio service load balancer host (alternative): $ISTIO_SERVICE_LB_HOST"
echo ""
echo "No host name? You can define a DNS A record e.g. for practicus.company.com using the below IP addresses"
echo " Istio ingress IP (preferred): $ISTIO_INGRESS_IP"
echo " Istio service load balancer IP (alternative): $ISTIO_SERVICE_LB_IP"
echo ""
