echo ""
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "Analyzing namespace $PRT_NS for istio issues"
istioctl analyze -n $PRT_NS

INGRESS_HOST=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].port}')
SECURE_INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="https")].port}')

export INGRESS_HOST
export INGRESS_PORT
export SECURE_INGRESS_PORT

echo "Detected Istio host and port info (can be updated later):"
echo "Detected INGRESS_HOST: $INGRESS_HOST"
echo "Detected INGRESS_PORT: $INGRESS_PORT"
echo "Detected SECURE_INGRESS_PORT: $SECURE_INGRESS_PORT"
