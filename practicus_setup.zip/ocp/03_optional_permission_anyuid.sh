#!/bin/bash

echo "For the below, *select* Practicus AI namespace workloads require root access"
echo "- Power users will require sudo access tobe able to install via apt-get"
echo "- Cloud Native PostgreSQL require privileged access"
echo "- All other workloads such as console, model hosting etc. work unprivileged"

echo ""
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "OpenShift - Adding policy"
oc adm policy add-scc-to-group anyuid system:serviceaccounts:$PRT_NS
