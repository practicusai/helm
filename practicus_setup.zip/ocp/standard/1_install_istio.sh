#!/bin/bash

echo ""
echo "Installing Istio for ** Red Hat OpenShift **"

echo "OpenShift - Adding policy"
oc adm policy add-scc-to-group anyuid system:serviceaccounts:istio-system

echo "OpenShift - Installing Istio"
istioctl install --set profile=openshift -y

echo "OpenShift - Exposing port"
oc -n istio-system expose svc/istio-ingressgateway --port=http2

echo ""
