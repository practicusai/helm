#!/bin/bash

echo ""
echo "Creating sample S3 compatible Object Storage"

echo "** IMPORTANT ** This object storage should only be used for testing or PoC scenarios. For HA, configure accordingly"

if [ -z "$PRT_NS_RUSTFS" ]; then
    export PRT_NS_RUSTFS=prt-ns-rustfs
    echo "PRT_NS_RUSTFS env variable is not defined, will use the default $PRT_NS_RUSTFS"
fi

kubectl create namespace "$PRT_NS_RUSTFS" || echo "$PRT_NS_RUSTFS already exists"

helm install practicus-rustfs practicusai/practicus-rustfs \
  --namespace "$PRT_NS_RUSTFS" \
  --values values-rustfs.yaml

echo ""
echo "Waiting until pods are ready in $PRT_NS_RUSTFS namespace"

kubectl wait --for=condition=ready --timeout=60s pod --all -n "$PRT_NS_RUSTFS"

echo ""
echo "For dev/test please add test_access_key to RustFS."

echo ""
