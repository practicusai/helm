echo ""
echo "Required for Production only - Creating private mutual TLS certificates and JWT keys."
echo "You can skip for local test installation and use the default keys."

GREEN='\033[0;92m' && RED='\033[0;91m' && NO_COLOR='\033[0m'
function fail {
    printf "${RED}\nERROR: %s\n\n" "$1" >&2
    exit 1
}

if [[ -z "$PRT_CERT_CN" ]]; then
    fail "Please define the certificates common name using:  export PRT_CERT_CN=*.mycompany.com"
    exit 1
fi

echo ""
echo "Certificate CN              : ${GREEN} $PRT_CERT_CN ${NO_COLOR}"
echo "Directory to write files to : ${GREEN} $PWD ${NO_COLOR}"
echo ""
echo "Please ${GREEN} hit enter to confirm ${NO_COLOR} or ${RED} CTRL+C to quit. ${NO_COLOR}"
read -r

rm -rf secrets
mkdir secrets

echo "Creating certificates for JWT (JSON Web Token)"
openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout ./secrets/jwt_private.pem -subj "/CN=$PRT_CERT_CN" > ./secrets/openssl.msg.txt

openssl rsa -in ./secrets/jwt_private.pem \
  -outform PEM -pubout -out ./secrets/jwt_public.pem > ./secrets/openssl.msg.txt

rm ./secrets/openssl.msg.txt

echo "Creating Self-signed SSL certificates for network traffic"
openssl req -x509 -newkey rsa:4096 -sha256 -days 3650 -nodes \
  -keyout ./secrets/ssl_key.pem -out ./secrets/ssl_cert.pem -subj "/CN=$PRT_CERT_CN"

echo ""
echo "IMPORTANT NOTE:"
echo "If your load balancer does not support SSL termination,"
echo " please replace secrets/ssl_cert.pem and ssl_key.pem files with your own SSL certificates."
echo " Not doing so will generate security warnings in browsers etc. due to self-signed certificates."
echo ""
