# Nod namespace defined? default to prt-ns
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
fi

# Starting
clear
echo "Enabling Istio for namespace $PRT_NS"
echo ""

echo "Injecting istio label for namespace"
kubectl label namespace prt-ns istio-injection=enabled

echo "OpenShift - Adding policy"
oc adm policy add-scc-to-group anyuid system:serviceaccounts:prt-ns

echo "OpenShift - Defining network attachment for CNI"
cat <<EOF | oc -n prt-ns create -f -
apiVersion: "k8s.cni.cncf.io/v1"
kind: NetworkAttachmentDefinition
metadata:
  name: istio-cni
EOF

echo ""
echo "Analyzing namespace $PRT_NS for istio issues"
istioctl analyze -n $PRT_NS

INGRESS_HOST=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="http2")].port}')
SECURE_INGRESS_PORT=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.spec.ports[?(@.name=="https")].port}')

export INGRESS_HOST
export INGRESS_PORT
export SECURE_INGRESS_PORT

echo "Istio host and port info:"
echo "INGRESS_HOST: $INGRESS_HOST"
echo "INGRESS_PORT: $INGRESS_PORT"
echo "SECURE_INGRESS_PORT: $SECURE_INGRESS_PORT"
