# Practicus in a box

## AWS EC2 

### Elastic IP (Optional)

- You might want to get a static ip address using AWS Elastic IP so that after EC2 restarts you don't have to change the DNS
- Open AWS Console > EC2 > Network & Security > Elastic IPs > Allocate Elastic IP address to get a static ip address

### Start a new instance

Launch a new Ubuntu 22.04 instance.

- Important: Please do not select Ubuntu 24
- Architecture x86
- Instance type: Min 16 GB RAM, 32GB or more RAM recommended.
- Allow SSH, HTTPS and HTTP traffic
- 250+ GB Storage

### Assign elastic IP (Optional)

If you got an elastic ip address:
- Open AWS Console > EC2 > Network & Security > Elastic IPs
- Select the ip address > Actions menu > Associate Elastic IP address > associate with the EC2 instance.
- Select the instance and private ip address of the ec2 instance you created. 
- Select "Allow this Elastic IP address to be reassociated" to be able keep ising this IP for multiple tests. 

### Define DNS entry on Route 53 

Now we need to route traffic to the EC2 instance. 
- Note the Elastic IP address (static address), if you got one, or view EC2 instance public IP address on EC2 > Instances > click on instance id > Networking > public IPv2 address. You can also use public dns.
- Open Route 53 > hosted zones and select the zone, e.g. my-company.com
- Create 2 DNS records, using A type if you are using ec2 ip address or elastic ip address, CNAME if you are using EC2 dns name.
- DNS record 1) subdomain = practicus  value = ip or dns 
- DNS record 2) subdomain = *.practicus  value = ip or dns
- We are using the same ip for both dns entries
- After this step, both practicus.my-company.com and some-addon.practicus.my-company.com will point to our EC2 instance.

### Reusing the Elastic IP

- Your ssh client can give a ssh REMOTE HOST IDENTIFICATION HAS CHANGED warning if you try to reconnect to a different ec2 instance with the same name due to static ip address.
- To fix, you can run the below 
- ssh-keygen -R [hostname-or-IP] 
- E.g. ssh-keygen -R ec2-12-13-111-122.compute-1.amazonaws.com
- In this scenario, 12.13.111.122 would be your elastic (static) ip address   


## Installation 

Please follow the below steps to install 

```shell

# Installing some prereqs
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get -y install unzip python3-venv python3-pip 

# Test http connectivity first 
# Start a simple http listener
sudo python3 -m http.server 80
# Open your browser and point to http://ip_address/ and http://dns_url/ to see basic html
# Stop simple html listener

# Install Microk8s
# Details from: https://microk8s.io/docs/getting-started
sudo snap install microk8s --classic --channel=1.29

sudo usermod -a -G microk8s $USER
mkdir -p ~/.kube
chmod 0700 ~/.kube

# Exit and reenter session
exit

microk8s status --wait-ready

# Do not use alias since it will not wor in scripts
# alias kubectl='microk8s kubectl'

microk8s enable dns 
microk8s enable dashboard 
microk8s enable hostpath-storage

# Important change the below to the appropriate ip address
# For Ec2: this should be your internal ec2 ip address and NOT elastic (static) ip address
# For on-prem, this can be the internal network traffic accessible ip address 
microk8s enable metallb:IP_ADDRESS-IP_ADDRESS

# Dashboard
# Get a token 
microk8s kubectl create token default
# Start dashboard tunnel - will not stop running
microk8s kubectl port-forward -n kube-system service/kubernetes-dashboard 8080:443

# Open a new terminal window and start a tunnel from your laptop to dashboard 
ssh -L 8080:127.0.0.1:8080 -i "your-pem-file.pem" user@host

# Open in your browser, ignore certificate warning
# https://localhost:8080/

# Open a 3rd terminal and continue installation 

sudo snap install kubectl --classic
echo "export KUBECONFIG=/var/snap/microk8s/current/credentials/client.config" >> ~/.bashrc
source .bashrc

kubectl get pod 

# Install helm
curl -fsSL -o get_helm.sh \
  https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3
chmod 700 get_helm.sh
./get_helm.sh
rm get_helm.sh

# Verify helm installation
helm version

cd ~ || exit
echo "Downloading Istio"
rm -rf istio
curl -L https://istio.io/downloadIstio | sh -
ISTIO_VERSION=$(echo istio*)
mv $ISTIO_VERSION istio
export PATH=~/istio/bin:$PATH

# Recommended: Add to .bashrc
echo "PATH=~/istio/bin:$PATH" >> ~/.bashrc 
source .bashrc 

cd ~ || exit
wget https://practicusai.github.io/helm/practicus_setup.zip
unzip practicus_setup.zip -d setup
cd setup || exit
```

After this step you should be able to continue from the regular setup steps.
