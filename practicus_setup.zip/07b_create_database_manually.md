# Creating a PostgreSQL Database and permissions

- Note: You can skip this step if you installed the database service with Practicus AI installation scripts since the database is already created part.  
- Please follow the below steps, or similar, to create a PostgreSQL database and set permissions  
- Note: The below are steps using the PGAdmin tool and other tools will be similar.

## 1) Create a login
- Connect to a PostgreSQL Server
- Right click server name > Create > Login/ Group Role
- General > Name: console_db_owner
- Definition > Password: <select a password>
- Privileges > Can Login? : Enabled

OR:


```sql
-- DROP ROLE IF EXISTS console_db_owner;

CREATE ROLE console_db_owner WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION
  PASSWORD 'console_db_pwd';
```

## 2) Create a database
- Right click server name > Create > Database
- General > Database: prt_console
- Security > Privileges > Click "+" > Grantee: console_db_owner, Privileges: ALL

OR:

```sql
-- DROP DATABASE IF EXISTS prt_console;

CREATE DATABASE prt_console
    WITH
    OWNER = console_db_owner
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

```

## 3) Grant permissions to the login on the database
- Right click the database name you just created (e.g. prt_console) > Query Tool
- Run the below SQL statement
- To restart, you can drop the public schema which will * delete all the existing tables in the schema *
 
```sql

GRANT ALL ON DATABASE prt_console TO console_db_owner;

```