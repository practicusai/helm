# Nod namespace defined? default to prt-ns
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
fi

helm install practicus-console practicusai/practicus-console \
  --namespace $PRT_NS \
  --values values-keys.yaml \
  --values values-prod-ocp2.yaml
