#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Creating Rabbit MQ Cluster using values-rabbitmq.yaml"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

# helm -n "$PRT_NS" uninstall practicus-rabbitmq

helm install practicus-rabbitmq practicusai/practicus-rabbitmq \
  --namespace "$PRT_NS" \
  --values values-rabbitmq.yaml

echo ""
