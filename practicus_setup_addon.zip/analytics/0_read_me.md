# Notes

## (Recommended) Load Sample Data for Sample Dashboards

If you would like to use Superset Sample Dashboards, please login to the terminal of one of the superset pods and run the following:

```shell
superset load_examples
```

## Nessie sample catalog

- Create a schema

```sql
CREATE SCHEMA lakehouse.default WITH ( LOCATION = 's3a://lakehouse/default/' )
```

- Create a table

```sql
CREATE TABLE lakehouse.default.example_table (
    c1 INTEGER,
    c2 DATE,
    c3 DOUBLE
)
WITH (
    format = 'PARQUET',
    location = 's3a://lakehouse/default/example_table/'
);
```

- Insert some data

```sql
INSERT INTO lakehouse.default.example_table (c1, c2, c3)
VALUES 
    (11, DATE '2024-05-29', 3.14),
    (21, DATE '2024-05-30', 2.71),
    (31, DATE '2024-05-31', 1.41),
    -- Add more rows here
    (1001, DATE '2024-08-06', 3.58),
    (1011, DATE '2024-08-07', 2.99);

SELECT * from lakehouse.default.example_table
```

## Connection from Superset

```text
# HTTP
trino://practicus-analytics-trino.prt-ns-analytics.svc.cluster.local:8080/lakehouse

# HTTPS
trino://practicus-analytics-trino.prt-ns-analytics.svc.cluster.local:8443/lakehouse

# Also works HTTPS
trino://trino.local.practicus.io:8443/lakehouse


```

- in advanced, secure extra

```json
{
    "auth_method": "basic",
    "auth_params": {
        "username": "admin",
        "password": "admin123"
    }
}

```

- Verify: False can have issues
- in advanced, secure extra, root certificate copy ca_cert.pem content that you used in certificate step
- OLD: in advanced, secure extra, root certificate copy prt-ns-analytics / certificates secret / tls.crt content
