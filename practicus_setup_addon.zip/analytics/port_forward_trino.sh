#!/bin/bash

SVC_NAME=practicus-analytics-trino
SVC_NAMESPACE=prt-ns-analytics

# kubectl port-forward svc/$SVC_NAME 8080:8080 -n $SVC_NAMESPACE

kubectl port-forward svc/$SVC_NAME 8443:8443 -n $SVC_NAMESPACE
