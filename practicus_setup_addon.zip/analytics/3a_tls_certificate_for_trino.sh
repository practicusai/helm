#!/bin/bash
#
# This script handles two certificate scenarios for Trino:
# 1) Use a self-signed certificate (generated and signed using your own CA).
# 2) Use an externally signed certificate (ssl_key.pem + ssl_cert.pem) and create a Kubernetes secret.

#######################################
# Variables
#######################################
SVC_NAMESPACE="prt-ns-analytics"
TRINO_SVC_HOST="trino.local.practicus.io"

# File paths for the self-signed scenario
CA_CERT_PATH="./secrets/ca_cert.pem"   # Your CA certificate
CA_KEY_PATH="./secrets/ca_key.pem"     # Your CA private key
SSL_KEY_PATH="./secrets/ssl_key.pem"   # Trino private key
CERT_CSR_PATH="trino_csr.pem"          # CSR file (Trino certificate request)
TRINO_CERT_PATH="trino_cert.pem"       # Signed certificate for Trino
CERT_EXT_PATH="cert_ext.cnf"           # Configuration file for SAN (Subject Alternative Names)


#######################################
# Functions
#######################################

function self_signed_scenario {
    echo ""
    echo ">>> [1] SELF-SIGNED CERTIFICATE SCENARIO <<<"
    echo "Switching to the script directory..."
    cd "$(dirname "$0")" || exit

    # 1. Generate a CSR using an existing private key
    echo "1) Generating CSR with the existing private key..."
    openssl req -new -key "$SSL_KEY_PATH" -out "$CERT_CSR_PATH" \
        -subj "/CN=$TRINO_SVC_HOST"

    # 2. Prepare the Subject Alternative Names (SAN) config
    echo "2) Preparing SAN (Subject Alternative Names) configuration..."
    cat <<EOF > "$CERT_EXT_PATH"
subjectAltName=DNS:localhost,DNS:$TRINO_SVC_HOST,DNS:*.$SVC_NAMESPACE,DNS:*.$SVC_NAMESPACE.svc,DNS:*.$SVC_NAMESPACE.svc.cluster.local,IP:127.0.0.1
EOF

    # 3. Sign the CSR using your own CA
    echo "3) Signing CSR with the CA certificate..."
    openssl x509 -req -in "$CERT_CSR_PATH" \
        -CA "$CA_CERT_PATH" \
        -CAkey "$CA_KEY_PATH" \
        -CAcreateserial \
        -out "$TRINO_CERT_PATH" \
        -days 365 \
        -sha256 \
        -extfile "$CERT_EXT_PATH"

    # 4. Prepare the Kubernetes namespace
    echo "4) Preparing the namespace $SVC_NAMESPACE ..."
    kubectl create namespace "$SVC_NAMESPACE" || echo ">> The $SVC_NAMESPACE namespace already exists, proceeding..."

    # 5. Remove any existing secret named 'certificates'
    echo "5) Removing any existing 'certificates' secret..."
    kubectl -n "$SVC_NAMESPACE" delete secret certificates || echo ">> No existing secret found."

    # 6. Create a new TLS secret for Trino
    echo "6) Creating a new 'certificates' secret..."
    kubectl -n "$SVC_NAMESPACE" create secret tls certificates \
        --cert="$TRINO_CERT_PATH" \
        --key="$SSL_KEY_PATH"

    # 7. Clean up temporary files
    echo "7) Cleaning up temporary files..."
    rm -f "$CERT_CSR_PATH" "$CERT_EXT_PATH"

    echo ""
    echo ">>> Self-signed certificate scenario completed. <<<"
    echo ""
}

function authority_cert_scenario {
    echo ""
    echo ">>> [2] EXTERNAL CA CERTIFICATE SCENARIO <<<"
    echo "Using an externally signed certificate (ssl_key.pem + ssl_cert.pem) and creating a Kubernetes secret."

    # Make sure that ssl_key.pem and ssl_cert.pem are available in your current directory 
    # or adjust the paths accordingly.

    # 1. Prepare the Kubernetes namespace
    echo "1) Preparing the namespace $SVC_NAMESPACE ..."
    kubectl create namespace "$SVC_NAMESPACE" || echo ">> The $SVC_NAMESPACE namespace already exists, proceeding..."

    # 2. Remove any existing 'certificates' secret
    echo "2) Removing any existing 'certificates' secret..."
    kubectl -n "$SVC_NAMESPACE" delete secret certificates || echo ">> No existing secret found."

    # 3. Create a new TLS secret using ssl_key.pem and ssl_cert.pem
    echo "3) Creating a new 'certificates' secret with the external cert and key..."
    kubectl -n "$SVC_NAMESPACE" create secret tls certificates \
        --cert=ssl_cert.pem \
        --key=ssl_key.pem

    echo ""
    echo ">>> External CA certificate scenario completed. <<<"
    echo ""
}


#######################################
# Selection Menu
#######################################
clear
echo "========================================="
echo "      TRINO CERTIFICATE MANAGER"
echo "========================================="
echo "Which certificate scenario do you want to run?"
echo "1) Use a self-signed certificate (self-signed CA)"
echo "2) Use an external CA-signed certificate (ssl_key.pem + ssl_cert.pem)"
read -p "Your choice [1-2]: " choice

case "$choice" in
    1)
        self_signed_scenario
        ;;
    2)
        authority_cert_scenario
        ;;
    *)
        echo "Invalid choice. Exiting..."
        exit 1
        ;;
esac
