# Notes

## (Recommended) Load Sample Data for Sample Dashboards

If you would like to use Superset Sample Dashboards, please login to the terminal of one of the superset pods and run the following:

```shell
superset load_examples
```

## Connection to Trino from Superset

```text
# HTTP
trino://practicus-trino.prt-ns-trino.svc.cluster.local:8080/lakehouse

# HTTPS
trino://practicus-trino.prt-ns-trino.svc.cluster.local:8443/lakehouse

# Also works HTTPS
trino://trino.local.practicus.io:8443/lakehouse


```

- in advanced, secure extra

```json
{
    "auth_method": "basic",
    "auth_params": {
        "username": "admin",
        "password": "admin123"
    }
}

```

- Verify: False can have issues
- in advanced, secure extra, root certificate copy ca_cert.pem content that you used in certificate step
- OLD: in advanced, secure extra, root certificate copy prt-ns-trino / certificates secret / tls.crt content
