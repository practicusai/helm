# NO SSO Support

At the time of the writing, Practicus AI Langflow service does not support Enterprise Single Sign On
