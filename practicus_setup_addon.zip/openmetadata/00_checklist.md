# Getting Started

Before you begin, please make sure you review the below list.

## Common Pre-requisites

- A Kubernetes cluster
- kubectl installed, and using the desired context (your target kubernetes cluster) 
- helm installed 
- DNS: You will need to be able to define new DNS entries e.g. "openmetadata.company.com" and "airflow-openmetadata.company.com"  

## Other Pre-requisites

- PostgreSQL DB Server 
  - If you don't have a DB server, you can use the practicus-pg-db helm chart optimized for Kubernetes  
  - You will need two databases, one for OpenMetadata and one for its internal Airflow (please see 02_create_db.md)
- Block storage 
  - Read-Write-Many (RWM) capable storage is required for OpenMetadata Airflow dags and logs persistence
- Kubernetes secrets for database, SSO and internal Airflow passwords (please see 03_create_secrets.md)
