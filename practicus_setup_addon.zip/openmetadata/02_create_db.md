# Creating PostgreSQL databases using pgAdmin 

- This guide will help you create the PostgreSQL databases required for your service 
- OpenMetadata requires two databases:
  - One for OpenMetadata itself (e.g. `prt_openmetadata_db`)
  - One for OpenMetadata's internal Airflow (e.g. `prt_openmetadata_airflow_db`)
- We will be using pgAdmin, but any other database management tool will be enough. 

### Connect to Server  

- Connect to your database using pgAdmin tool. 
- Note: If your database is in Kubernetes you will have to open a network tunnel to your computer first. Please see below of this file to learn how.   

### Option 1) Creating Login and DB using GUI 

- Right-click your database server, Create > login > select a name e.g. "prt_openmetadata_user" 
  - Definition > select a secure password
  - Privileges > grant login permission.   
- Right-click the server, Create > Database > select a name e.g 'prt_openmetadata_db', leave owner default
  - Security > Privileges > click "+" to add > Select "prt_openmetadata_user" as Grantee and select All privileges. 
- Repeat the same steps for the internal Airflow database, e.g. login "prt_openmetadata_airflow_user" and database "prt_openmetadata_airflow_db"

### Option 2) Creating Login and DB using SQL 
 
- *IF* you have a PSQL enabled for remote server, you can use the below to create the databases.

```sql

-- DROP ROLE IF EXISTS prt_openmetadata_user;

CREATE ROLE prt_openmetadata_user WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION
  PASSWORD '**** add your password here ****';

-- DROP DATABASE IF EXISTS prt_openmetadata_db;

CREATE DATABASE prt_openmetadata_db
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

GRANT ALL ON DATABASE prt_openmetadata_db TO prt_openmetadata_user;

-- DROP ROLE IF EXISTS prt_openmetadata_airflow_user;

CREATE ROLE prt_openmetadata_airflow_user WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION
  PASSWORD '**** add your password here ****';

-- DROP DATABASE IF EXISTS prt_openmetadata_airflow_db;

CREATE DATABASE prt_openmetadata_airflow_db
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

GRANT ALL ON DATABASE prt_openmetadata_airflow_db TO prt_openmetadata_airflow_user;

```

### Grant permission to schema

- Right-click the newly created "prt_openmetadata_db" database > Query Tool
- Run the below SQL 

```sql
GRANT ALL ON SCHEMA public TO prt_openmetadata_user;
```

- Repeat the same for the "prt_openmetadata_airflow_db" database

```sql
GRANT ALL ON SCHEMA public TO prt_openmetadata_airflow_user;
```

### Update values.yaml

- Update values.yaml with the OpenMetadata database name, user and host information.
- Update values-dependencies.yaml with the internal Airflow database name, user and host information.

### Appendix

#### Opening a tunnel for your db on Kubernetes
 
- If you installed the database server using practicus-pg-db helm chart with default values, you can use the below to open tunnel and connect the db from your computer  

```shell
echo "Starting temporary connection tunnel"
kubectl -n prt-ns port-forward service/prt-db-pg-1-rw 5432:5432
```
