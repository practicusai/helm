# Configuring your service using values.yaml

- OpenMetadata consists of two helm charts:
  - `practicus-openmetadata-dependencies`: internal Airflow, OpenSearch and other dependencies. Configured using **values-dependencies.yaml**
  - `practicus-openmetadata`: OpenMetadata server itself. Configured using **values.yaml**
- Both values files must be downloaded to the service directory after you run 01_prepare.sh script 
- Please go through all the settings and update as needed.
- Practicus AI and parent chart values.yaml files also acts as the setup documentation of the service. After you review Practicus AI values.yaml files, you can also go through parent chart .yaml files to fine tune your configuration.     
- Tip: You can delete values.yaml sections that are not used, so future helm updates can automatically update those parts.

# Changing default service name and namespace

- If you would like to change the default service name and namespace you can set PRT_SVC_NAME and PRT_SVC_NAMESPACE environment variables before running 11_install.sh script
- Since OpenMetadata has two charts, you can also set PRT_DEPS_SVC_NAME to change the dependencies release name.
- Important! If you change PRT_DEPS_SVC_NAME, you must also update `openmetadata.config.pipelineServiceClientConfig.airflow.apiEndpoint` in values.yaml, since OpenMetadata server connects to its internal Airflow using the dependencies release name. E.g. `http://<PRT_DEPS_SVC_NAME>-web:8080`
- E.g. :

```shell
export PRT_SVC_NAME=my-custom-service-name
export PRT_DEPS_SVC_NAME=my-custom-service-name-dependencies
export PRT_SVC_NAMESPACE=my-custom-service-namespace
```
