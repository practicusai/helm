#!/bin/bash

SERVICE_KEY=openmetadata
DEFAULT_SVC_NAME=practicus-openmetadata
DEFAULT_DEPS_SVC_NAME=practicus-openmetadata-dependencies
DEFAULT_SVC_NAMESPACE=prt-ns-openmetadata

cd "$(dirname "$0")" || exit

if [ -z "$PRT_SVC_NAME" ]; then
    export PRT_SVC_NAME=$DEFAULT_SVC_NAME
    echo "PRT_SVC_NAME env variable is not defined, will use the default $PRT_SVC_NAME"
fi

if [ -z "$PRT_DEPS_SVC_NAME" ]; then
    export PRT_DEPS_SVC_NAME=$DEFAULT_DEPS_SVC_NAME
    echo "PRT_DEPS_SVC_NAME env variable is not defined, will use the default $PRT_DEPS_SVC_NAME"
fi

if [ -z "$PRT_SVC_NAMESPACE" ]; then
    export PRT_SVC_NAMESPACE=$DEFAULT_SVC_NAMESPACE
    echo "PRT_SVC_NAMESPACE env variable is not defined, will use the default $PRT_SVC_NAMESPACE"
fi

echo ""
echo "Upgrading $PRT_DEPS_SVC_NAME"
helm upgrade "$PRT_DEPS_SVC_NAME" "practicusai/practicus-$SERVICE_KEY-dependencies" \
  --namespace "$PRT_SVC_NAMESPACE" \
  --values "values-dependencies.yaml"

echo "Completed upgrading $PRT_DEPS_SVC_NAME"

echo ""
echo "Upgrading $PRT_SVC_NAME"
helm upgrade "$PRT_SVC_NAME" "practicusai/practicus-$SERVICE_KEY" \
  --namespace "$PRT_SVC_NAMESPACE" \
  --values "values.yaml"

echo "Completed upgrading $PRT_SVC_NAME"
