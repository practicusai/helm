# Setting up Enterprise Single Sign-On

- OpenMetadata Practicus AI service requires Enterprise SSO to operate.

## Step 1) Create an SSO App
- Visit Practicus AI admin console > Ent. Single Sign-On > Applications > Add application
- Note "Client id"
- Enter the below in "Redirect uris" section by replacing service DNS entry E.g. : 
- https://openmetadata-practicus.my-company.com/callback
- Select "Confidential" for "Client type" section.
- Select "Authorization code" for "Authorization grant type"
- Carefully note "Client secret". *Secret will not be displayed again* 
- Enter a meaningful SSO app name. E.g: "openmetadata-primary-sso" This name is for internal use only. 
- Select "skip authorization". 
  - Note: We can skip authorization so the users are not asked to "accept" for the service to authenticate with Practicus AI. Since you own all the services, explicit user confirmation is not needed. 
- Select "RSA with SHA-2 256" option for "Algorithm"
- Save the SSO app.

## Step 2) Create the oidc-secrets Kubernetes secret
- Using the "Client id" and "Client secret" from the above step, create the `oidc-secrets` secret.
- Please see 03_create_secrets.md for details.

## Step 3) Create the service
- Visit Practicus AI admin console > Services > Add Service
- Select a service key E.g. "openmetadata-primary". 
  - This key can be end user facing via SDK use.
- Select an end-user friendly name for the service E.g. "OpenMetadata Primary". 
  - Although service name is mostly for GUIs, SDK calls can also be made using names.
- Select Service Type
- Enter primary url E.g. :
- https://openmetadata-practicus.my-company.com/
- Select the SSO app you created in the above step.
- You do not need to setup additional db, object storage etc settings since these will be set in helm chart
- Grant access to the service using groups (recommended) or individual users. 
- Click Save
