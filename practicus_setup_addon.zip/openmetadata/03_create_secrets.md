# Creating Kubernetes secrets

- OpenMetadata helm charts expect the below secrets to be created **before** installation.
- Please create them in the service namespace (default: `prt-ns-openmetadata`).

## 1) Database password secret

- Holds the PostgreSQL password of `prt_openmetadata_user`.
- Referenced in values.yaml as `openmetadata.config.database.auth.password`.

```shell
kubectl -n prt-ns-openmetadata create secret generic postgres-secrets \
  --from-literal=openmetadata-postgres-password='**** add your db password here ****'
```

## 2) SSO (OIDC) secret

- Holds the client id and client secret of the SSO app you created (please see 04_setup_sso.md).
- Referenced in values.yaml as `openmetadata.config.authentication.oidcConfiguration`.

```shell
kubectl -n prt-ns-openmetadata create secret generic oidc-secrets \
  --from-literal=openmetadata-oidc-client-id='**** add your client id here ****' \
  --from-literal=openmetadata-oidc-client-secret='**** add your client secret here ****'
```

## 3) Internal Airflow password secret

- Holds the password OpenMetadata server uses to login to its internal Airflow.
- Important! This password must match `openmetadatadependencies.airflow.airflow.defaultUser.password` in values-dependencies.yaml.

```shell
kubectl -n prt-ns-openmetadata create secret generic airflow-secrets \
  --from-literal=openmetadata-airflow-password='**** add your airflow password here ****'
```

## Notes

- If you use a custom namespace, please replace `prt-ns-openmetadata` with your namespace.
- If the secrets already exist, delete them first with `kubectl -n prt-ns-openmetadata delete secret <secret-name>` or use `kubectl apply` with secret manifests.
