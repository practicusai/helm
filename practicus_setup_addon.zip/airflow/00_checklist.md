# Getting Started

Before you begin, please make sure you review the below list.

## Common Pre-requisites

- A Kubernetes cluster
- kubectl installed, and using the desired context (your target kubernetes cluster) 
- helm installed 
- DNS: You will need to be able to define a new DNS entry e.g. "my-practicus-service.company.com"  

## Other Pre-requisites

- PostgreSQL DB Server 
  - If you don't have a DB server, you can use the practicus-pg-db helm chart optimized for Kubernetes  
- Block storage 
- Git 
  - A git service e.g. Github, GitLab, BitBucket, or open source girt system such as Gitea
  - A git repo for Airflow DAGs and 
  - You should be able to create ssh keys for the git repo
  - We need read-only access for Airflow and read-write for Practicus AI git service
