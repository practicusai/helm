# Setting up Enterprise Single Sign-On

- Practicus AI Observability services require Enterprise SSO to operate.
- Please note that it is common to have a single observability stack for multiple services, namespaces. 

## Step 1) Create an SSO App for Grafana
- Visit Practicus AI admin console > Ent. Single Sign-On > Applications > Add application
- Note "Client id"
- Enter the below in "Redirect uris" section by replacing service DNS entry E.g. : 
- https://grafana-practicus.company.com/login/generic_oauth
- Select "Confidential" for "Client type" section.
- Select "Authorization code" for "Authorization grant type"
- Carefully note "Client secret". *Secret will not be displayed again* 
- Enter a meaningful SSO app name. E.g: "grafana-sso" This name is for internal use only. 
- Select "skip authorization". 
  - Note: We can skip authorization so the users are not asked to "accept" for the service to authenticate with Practicus AI. Since you own all the services, explicit user confirmation is not needed. 
- Select "RSA with SHA-2 256" option for "Algorithm"
- Save the SSO app.

## Step 2) Create the service
- Visit Practicus AI admin console > Services > Add Service
- Select a service key E.g. "grafana". 
- Select an end-user friendly name for the service E.g. "Grafana". 
- Select Service Type
- Enter "primary url" E.g. :
- https://grafana-practicus.company.com/
- Select the SSO app you created in the above step.
- You do not need to setup additional db, object storage etc settings since these wil lbe set in helm chart
- Grant access to the service using groups (recommended) or individual users. 
  - Grafana does not use editor/admin etc. permissions from Practicus AI. 
  - All logged-in users will be "Viewers" and you can change their permissions using the Grafana UI. 
  - You will use "Grafana admin" user / password for first time login to the Grafana UI and the rest can be via SSO.
- Click Save
