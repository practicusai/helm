# Getting Started

Before you begin, please make sure you review the below list.

## Common Pre-requisites

- A Kubernetes cluster
- kubectl installed, and using the desired context (your target kubernetes cluster) 
- helm installed 
- DNS: You will need to be able to define a new DNS entry e.g. "my-practicus-service.company.com"  

## Other Pre-requisites

- Object Storage
- Block storage
