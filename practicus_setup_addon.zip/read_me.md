# Practicus AI External Services setup guide

## Introduction 

Practicus AI external services are optional and supplementary services such as:

- Airflow for data and ML pipeline orchestration
- MLflow for ML experiment management
- Observability (o11y) services such as:
  - Prometheus time series database for metrics
  - Fluent Bit to collect logs
  - Loki to store and analyze logs
  - Grafana to visualize and alert metrics, logs and traces
- Peppermint for issue tracking 

## Open Source Licenses 

Please note that these services have different type of open source licenses that you can review using their respective GitHub pages.

## Get Started 

- To start installing please navigate each service folder and follow the steps. 

