# Configurations specific to prefect

{{- define "addonSpecificConfigMap" }}

{{- if .Values.prefect.skipCreatingWorkPool }}
  PRT_PROXY_SKIP_CREATING_WORK_POOL: {{ quote .Values.prefect.skipCreatingWorkPool }}
{{- end }}

{{- if .Values.prefect.workPoolName }}
  PRT_PROXY_WORK_POOL_NAME: {{ quote .Values.prefect.workPoolName }}
{{- end }}

{{- if .Values.prefect.workerProcessCount }}
  PRT_PROXY_WORKER_PROCESS_COUNT: {{ quote .Values.prefect.workerProcessCount }}
{{- end }}

{{- if .Values.prefect.workPoolConcurrencyLimit }}
  PRT_PROXY_WORK_POOL_CONCURRENCY_LIMIT: {{ quote .Values.prefect.workPoolConcurrencyLimit }}
{{- end }}

{{- end }}


{{- define "addonSpecificSecret" }}


{{- end }}
