"""Render the chart and test its actual recording rules; no live backend calls.

Run: HELM=/path/to/helm PROMTOOL=/path/to/promtool python3 tests/test_recording_rules.py
Requires PyYAML. Temporary rendered artifacts are kept outside the worktree.
"""

# PyYAML documents have dynamic nested shapes at this serialization boundary.
# pyright: reportAny=false

# Local test runner invokes operator-selected tools.
import os
import re
import subprocess  # nosec B404
import tempfile
from pathlib import Path
from typing import TypedDict

import yaml


class ConfigMapDocument(TypedDict, total=False):
    kind: str
    data: dict[str, str]


class RecordingRule(TypedDict):
    record: str
    expr: str


class RuleGroup(TypedDict):
    rules: list[RecordingRule]


def check_router_metadata(documents: list[ConfigMapDocument]) -> None:
    configs = [
        doc.get("data", {})["fluent-bit.conf"]
        for doc in documents
        if doc.get("kind") == "ConfigMap" and "fluent-bit.conf" in doc.get("data", {})
    ]
    if len(configs) != 1:
        raise AssertionError("Expected exactly one rendered Fluent Bit config")
    # Record accessors contain brackets; split on section headers instead.
    outputs = re.split(r"(?m)^\s*\[OUTPUT\]\s*$", configs[0])[1:]
    container_outputs = [
        section
        for section in outputs
        if re.search(r"(?m)^\s*match\s+kube\.\*\s*$", section)
    ]
    if len(container_outputs) != 1:
        raise AssertionError("Expected exactly one container log output")
    metadata = re.findall(r"(?m)^\s*structured_metadata\s+(.+)$", container_outputs[0])
    if len(metadata) != 1:
        raise AssertionError("Expected exactly one structured metadata mapping")
    mappings = [item.strip() for item in metadata[0].split(",")]
    for key in (
        "router_mode",
        "router_stage",
        "router_latest",
        "router_weight",
        "router_share",
        "router_verified",
    ):
        if mappings.count(f"{key}=${key}") != 1:
            raise AssertionError(
                f"Expected exactly one structured metadata mapping for {key}"
            )
    for labels in re.findall(r"(?m)^\s*(?:labels|label_keys)\s+(.+)$", configs[0]):
        if "router_" in labels:
            raise AssertionError("Router fields must never be Loki stream labels")
    print(f"Rendered Fluent Bit structured_metadata: {metadata[0]}", flush=True)
    for directive in re.findall(r"(?m)^\s*((?:labels|label_keys)\s+.+)$", configs[0]):
        print(f"Rendered Fluent Bit {directive}", flush=True)
    print("Rendered Loki stream labels contain no router fields", flush=True)


def check_red_identity(groups: list[RuleGroup]) -> None:
    identities = {
        "apphost": ["namespace", "runtime", "app_id", "app_version"],
        "modelhost": [
            "namespace",
            "runtime",
            "deployment_key",
            "model_id",
            "model_version",
        ],
    }
    for runtime, identity in identities.items():
        for suffix in ("requests:rate5m", "5xx:rate5m", "duration:p95_5m"):
            name = f"{runtime}:practicus_http_{suffix}"
            rules = [
                rule
                for group in groups
                for rule in group["rules"]
                if rule["record"] == name
            ]
            if len(rules) != 1:
                raise AssertionError(f"Expected exactly one RED rule: {name}")
            expected = identity + (["le"] if suffix == "duration:p95_5m" else [])
            sums = re.findall(r"sum by \(([^)]+)\)", rules[0]["expr"])
            if not sums or any(
                [label.strip() for label in labels.split(",")] != expected
                for labels in sums
            ):
                raise AssertionError(
                    f"{name} must sum by identity (and le for histogram) only"
                )
            if "router_" in rules[0]["expr"]:
                raise AssertionError(
                    f"{name} must not filter or group by router fields"
                )
    print(
        "Rendered RED rules sum by identity only; router_mode aggregates away",
        flush=True,
    )


def main() -> None:
    chart = Path(__file__).resolve().parents[1]
    # Trusted local CLI, no shell or remote input.
    rendered = subprocess.run(  # nosec B603
        [
            os.environ.get("HELM", "helm"),
            "template",
            "practicus-o11y",
            str(chart),
            "--namespace",
            "prt-ns-o11y",
        ],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    documents = [doc for doc in yaml.safe_load_all(rendered) if doc]
    check_router_metadata(documents)
    tempo_configs = [
        yaml.safe_load(doc["data"]["tempo.yaml"])
        for doc in documents
        if doc.get("kind") == "ConfigMap" and "tempo.yaml" in doc.get("data", {})
    ]
    if len(tempo_configs) != 1:
        raise AssertionError("Expected exactly one rendered Tempo config")
    if tempo_configs[0]["compactor"]["compaction"]["block_retention"] != "72h":
        raise AssertionError("Rendered Tempo block_retention must be 72h")
    print("Rendered Tempo compactor block_retention: 72h", flush=True)
    rules = [
        doc["spec"]
        for doc in documents
        if doc.get("kind") == "PrometheusRule"
        and doc["metadata"]["name"] == "practicus-o11y-watchtower"
    ]
    if len(rules) != 1:
        raise AssertionError("Expected exactly one Watchtower rule group")
    check_red_identity(rules[0]["groups"])
    with tempfile.TemporaryDirectory(prefix="o11y-rule-tests-") as directory:
        work = Path(directory)
        _ = (work / "rendered_rules.yaml").write_text(yaml.safe_dump(rules[0]))
        _ = (work / "recording_rules_test.yaml").write_text(
            (chart / "tests" / "recording_rules_test.yaml").read_text()
        )
        # Trusted local CLI, no shell or remote input.
        _ = subprocess.run(  # nosec B603
            [
                os.environ.get("PROMTOOL", "promtool"),
                "test",
                "rules",
                str(work / "recording_rules_test.yaml"),
            ],
            cwd=work,
            check=True,
        )


if __name__ == "__main__":
    main()
