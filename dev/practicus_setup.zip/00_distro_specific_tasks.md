# Kubernetes distribution specific tasks

- Please check the distro folder for help on specific Kubernetes distributions such as Red Hat OpenShift, minikube on Windows etc.
- HyperScaler kubernetes environments such as AWS EKS will work as-is.
