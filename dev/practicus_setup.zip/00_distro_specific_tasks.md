# Kubernetes distribution specific tasks

- Please check the distro folder for help on specific Kubernetes distributions such as Red Hat OpenShift, minikube on Windows etc.
- Cloud Kubernetes environments may require provider-specific ingress configuration.
- On AWS EKS with the Practicus ALB Ingress, `02_install_istio.sh` selects
  `NodePort` automatically for a new installation. You can also set it explicitly:

  ```shell
  export PRT_ISTIO_GATEWAY_SERVICE_TYPE=NodePort
  ```

  The ALB uses instance targets that reach Istio through a NodePort. Using
  `LoadBalancer` also provisions an unwanted Classic Load Balancer or NLB.
