#!/bin/bash

echo ""
echo "Required for Production only - Creating private mutual TLS certificates and JWT keys."
echo "You can skip for local test installation and use the default keys."

function fail {
    printf "\nERROR: %s\n\n" "$1" >&2
    exit 1
}

if [[ -z "$PRT_CERT_CN" ]]; then
    fail "Please define the certificates common name using:  export PRT_CERT_CN=*.mycompany.com"
    exit 1
fi

echo ""
echo "Certificate CN              : $PRT_CERT_CN"
echo "Directory to write files to : $PWD"
echo ""
echo "Please hit enter to confirm or CTRL+C to quit."
read -r

rm -rf secrets
mkdir secrets

echo "Creating certificates for JWT (JSON Web Token)"
openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout ./secrets/jwt_private.pem -subj "/CN=$PRT_CERT_CN" > ./secrets/openssl.msg.txt

openssl rsa -in ./secrets/jwt_private.pem \
  -outform PEM -pubout -out ./secrets/jwt_public.pem > ./secrets/openssl.msg.txt

rm ./secrets/openssl.msg.txt

echo "Creating Self-signed SSL certificates for network traffic"
openssl req -x509 -newkey rsa:4096 -sha256 -days 3650 -nodes \
  -keyout ./secrets/ssl_key.pem -out ./secrets/ssl_cert.pem -subj "/CN=$PRT_CERT_CN"

echo ""
echo "IMPORTANT NOTE:"
echo "If your load balancer does not support SSL termination,"
echo " please replace secrets/ssl_cert.pem and ssl_key.pem files with your own SSL certificates."
echo " Not doing so will generate security warnings in browsers etc. due to self-signed certificates."
echo ""
