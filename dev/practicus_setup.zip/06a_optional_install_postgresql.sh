#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Installing Cloud Native Postgresql controller"
echo "You can check the docs on https://cloudnative-pg.io/"

helm repo add cnpg https://cloudnative-pg.github.io/charts
helm repo update

helm upgrade --install cnpg \
  --namespace cnpg-system \
  --create-namespace \
  cnpg/cloudnative-pg

echo ""
echo "Waiting until pods under cnpg-system namespace are ready.."

kubectl wait --for=condition=ready --timeout=60s pod --all -n cnpg-system

echo ""
echo "Cloud Native PostgreSQL is ready!"
