#!/bin/bash

echo ""
echo "Installing Cloud Native Postgresql controller"
echo "You can check the docs on https://cloudnative-pg.io/documentation/1.22/"

kubectl apply --server-side -f \
  https://raw.githubusercontent.com/cloudnative-pg/cloudnative-pg/release-1.22/releases/cnpg-1.22.3.yaml

echo ""
echo "Waiting until pods under cnpg-system namespace are ready.."

kubectl wait --for=condition=ready --timeout=60s pod --all -n cnpg-system

echo ""
echo "Cloud Native PostgreSQL is ready!"
