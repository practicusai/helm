#!/bin/bash

clear
echo "** Preparing for BETA version - Only use for dev/test scenarios! **"
echo
echo "You are installing a beta release *NOT* ideal for production!"
echo "Please hit enter to confirm or CTRL+C to quit."
read -r

echo ""
echo "Adding practicusai-dev helm repo - BETA VERSION"
helm repo add practicusai-dev https://practicusai.github.io/helm/dev || echo " - Practicus AI helm repo already added"

echo "Updating all helm repos on your computer"
helm repo update

echo "Pulling helm chart"
rm -r "./practicus-console" || echo " - No current helm files to delete, all good."
helm pull "practicusai-dev/practicus-console" --untar

echo "Copying default values.yaml as values-chart.yaml"
cp "./practicus-console/values.yaml" ./values-chart.yaml

echo ""
echo "Completed preparing"
echo "You can view available charts in practicusai repo running the below:"
echo "helm search repo practicusai-dev"
echo ""

echo ""
echo "Important! Please verify current kubectl context before installing."
current_kubectl_context=$(kubectl config current-context)
echo "Current kubernetes context: $current_kubectl_context"

echo ""