# Creating a PostgreSQL Database and permissions

- Note: You can skip this step if you installed the database service with Practicus AI installation scripts since the database is already created part.  
- Please follow the below steps, or similar, to create a PostgreSQL database and set permissions  
- Note: The below are steps using the PGAdmin tool and other tools will be similar.

## 1) Create a login
- Connect to a PostgreSQL Server
- Right click server name > Create > Login/ Group Role
- General > Name: prt_console_admin
- Definition > Password: <select a password>
- Privileges > Can Login? : Enabled

## 2) Create a database
- Right click server name > Create > Database
- General > Database: prt_console
- Security > Privileges > Click "+" > Grantee: prt_console_admin, Privileges: ALL

## 3) Grant permissions to the login on the database
- Right click the database name you just created (e.g. prt_console) > Query Tool
- Run the below SQL statement
- To restart, you can drop the public schema which will * delete all the existing tables in the schema *
 
```sql
-- DROP SCHEMA IF EXISTS public CASCADE;

CREATE SCHEMA IF NOT EXISTS public
    AUTHORIZATION pg_database_owner;

COMMENT ON SCHEMA public
    IS 'standard public schema';

GRANT USAGE ON SCHEMA public TO PUBLIC;

GRANT ALL ON SCHEMA public TO pg_database_owner;

-- Select the correct login name if you changed the default
GRANT ALL ON SCHEMA public TO prt_console_admin;
```