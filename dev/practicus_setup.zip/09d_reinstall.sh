#!/bin/bash

cd "$(dirname "$0")" || exit

./09c_uninstall.sh
./09a_install.sh

echo ""
