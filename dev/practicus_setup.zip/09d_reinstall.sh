#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Re-installing Practicus AI"

./09c_uninstall.sh
./09a_install.sh

echo ""
