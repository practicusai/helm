- Please check the distro folder for help on specific Kubernetes distributions such as Red Hat OpenShift, minikube on Windows etc.
- On AWS EKS with the Practicus ALB Ingress, keep
  `PRT_ISTIO_GATEWAY_SERVICE_TYPE=NodePort` set whenever running an Istio
  install or reconciliation. A `LoadBalancer` Istio Service creates a second,
  unnecessary AWS load balancer.
