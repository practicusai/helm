# Updating values.yaml file(s)
- There are several values-*.yaml example files in this folder. 
- Please view each and choose options best suitable for your needs 

## PostgreSQL Database (Optional)
If you are also installing a PostgreSQL database, please update values-pg-db.yaml with database size, passwords etc.

## Practicus AI Console

- Please choose one of the values-local-test.yaml, values-prod.yaml etc. files, rename to values.yaml and update accordingly with your database and other settings. 
- Please check http://docs.practicus.ai/k8s-setup/ if you need help with values.yaml file settings.
- In order to update values-keys.yaml, you can use the supporting create certs script in this directory, or you can update them manually as well. 
- You will ideally define a DNS address e.g. for practicus.company.com pointing to Istio ingress external load balancer. And then add this dns to the hosts: list in values.yaml. 
- You can run 4_validate_istio.sh to detect the host. Depending on your Kubernetes cluster, the external address can be viewed checking the istio-system namespace: istio-ingressgateway service and/or istio-system ingress.   
