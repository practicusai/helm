#!/bin/bash

cd "$(dirname "$0")" || exit

chmod +x 09b_uninstall_console.sh
./09b_uninstall_console.sh

chmod +x 09a_install_console.sh
./09a_install_console.sh

echo ""
