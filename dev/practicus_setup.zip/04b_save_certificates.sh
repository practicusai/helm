#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Saving ./secrets contents to values-keys.yaml"

if [ -d venv ]; then
  echo "Existing Python virtual env found for this script. Version:"
  ./venv/bin/python3 --version || fail "Python3 venv not found, please install python first. Exiting script."
else
  echo "Current system Python version is:"
  python3 --version || fail "Python3 not found, please install python first. Exiting script."

  echo "Creating a temporary Python virtual environment for libraries needed during setup"
  python3 -m venv ./venv
  echo "Installing supporting security libraries"
  ./venv/bin/python3 -m pip install --upgrade pip
  ./venv/bin/python3 -m pip install jwcrypto
fi

echo ""
echo "Saving contents of ./secrets to values-keys.yaml"
echo "Saving certificates (contents of ./secrets folder) to values-keys.yaml for Kubernetes"
./venv/bin/python3 other/helper.py

echo ""
