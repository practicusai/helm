#!/bin/bash

clear

echo ""
echo "Saving ./secrets contents to values-keys.yaml"

cd "$(dirname "$0")" || exit

if [ -z "$PRT_SELF_SIGNED_CERT" ] || [ "$PRT_SELF_SIGNED_CERT" = true ]; then
  if [ -z "$PRT_SELF_SIGNED_CERT_INCLUDE_PUBLIC" ]; then
      export PRT_SELF_SIGNED_CERT_INCLUDE_PUBLIC=true
  fi
fi

if [ "$PRT_SELF_SIGNED_CERT_INCLUDE_PUBLIC" = true ]; then
    echo
    echo "********************************************************************************************"
    echo "IMPORTANT NOTE ON INTERNET (MOZILLA) CERTIFICATES "
    echo "********************************************************************************************"
    echo "You are using self-signed certificates, and the internet certificates (Mozilla public)"
    echo "  will be 'appended' to your private certificates. You can change this setting. "
    echo
    echo "Reasons to include public certificates:"
    echo "  If you use private certificates 'without' the public ones, some services might not be able "
    echo "    access the internet. E.g. python 'requests' library might fail to access an external "
    echo "    https address such as https://google.com, but linux apt-get command would still work. "
    echo
    echo "Reasons to skip including public certificates:"
    echo "  Internet certificates are several hundred KB in size and many of them are already present "
    echo "    on the OS. This is an additional system overhead. If end users will mostly work offline "
    echo "    you can safely skip including public certificates. "
    echo
    echo "If you would like to skip including public certificates, please quit now and run: "
    echo "  export PRT_SELF_SIGNED_CERT_INCLUDE_PUBLIC=false"
    echo "********************************************************************************************"
    echo
    echo "Please hit enter to confirm or CTRL+C to quit."
    read -r
fi


if [ -d venv ]; then
  echo "Existing Python virtual env found for this script. Version:"
  ./venv/bin/python3 --version || fail "Python3 venv not found, please install python first. Exiting script."
else
  echo "Current system Python version is:"
  python3 --version || fail "Python3 not found, please install python first. Exiting script."

  echo "Creating a temporary Python virtual environment for libraries needed during setup"
  python3 -m venv ./venv
fi

echo "Installing supporting security libraries"
./venv/bin/python3 -m pip install --upgrade pip
./venv/bin/python3 -m pip install jwcrypto certifi

echo ""
echo "Saving contents of ./secrets to values-keys.yaml"
echo "Saving certificates (contents of ./secrets folder) to values-keys.yaml for Kubernetes"
./venv/bin/python3 other/helper.py

echo ""
