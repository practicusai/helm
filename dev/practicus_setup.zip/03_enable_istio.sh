#!/bin/bash

echo "Most Kubernetes clusters do not need extra steps to enable istio"
echo "Please check sub folders for specific kubernetes environments"