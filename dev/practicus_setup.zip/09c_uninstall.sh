#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Uninstalling Practicus AI"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

helm uninstall practicus-console \
  --namespace "$PRT_NS"

echo ""
