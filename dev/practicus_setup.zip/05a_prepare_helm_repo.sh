#!/bin/bash

clear

cd "$(dirname "$0")" || exit

echo ""
echo "Adding practicusai helm repo"
helm repo add practicusai https://practicusai.github.io/helm || echo " - Practicus AI helm repo already added"

echo "Updating all helm repos on your computer"
helm repo update

rm -rf "practicusai" || echo " - No current helm files to delete, all good."

mkdir practicusai || echo "practicusai folder exists"
cd practicusai || exit

echo "Pulling helm charts"
helm pull "practicusai/practicus-console" --untar
helm pull "practicusai/practicus-pg-db" --untar
helm pull "practicusai/practicus-rabbitmq" --untar
helm pull "practicusai/practicus-simpleobj" --untar
cd ..

echo "Copying default values.yaml as values-chart.yaml"
cp "./practicusai/practicus-console/values.yaml" ./values-chart.yaml

echo ""
echo "Completed preparing"
echo "You can view available charts in practicusai repo running the below:"
echo "helm search repo practicusai"
echo ""

echo ""
echo "Important! Please verify current kubectl context before installing."
current_kubectl_context=$(kubectl config current-context)
echo "Current kubernetes context: $current_kubectl_context"

echo ""