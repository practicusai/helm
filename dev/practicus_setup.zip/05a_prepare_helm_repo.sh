#!/bin/bash

clear
echo ""
echo "Adding practicusai helm repo"
helm repo add practicusai https://practicusai.github.io/helm || echo " - Practicus AI helm repo already added"

echo "Updating all helm repos on your computer"
helm repo update

rm -rf "practicusai/practicus-console" || echo " - No current helm files to delete, all good."

mkdir practicusai || echo "practicusai folder exists"
cd practicusai || exit

echo "Pulling helm chart"
helm pull "practicusai/practicus-console" --untar
cd ..

echo "Copying default values.yaml as values-chart.yaml"
cp "./practicus-console/values.yaml" ./values-chart.yaml

echo ""
echo "Completed preparing"
echo "You can view available charts in practicusai repo running the below:"
echo "helm search repo practicusai"
echo ""

echo ""
echo "Important! Please verify current kubectl context before installing."
current_kubectl_context=$(kubectl config current-context)
echo "Current kubernetes context: $current_kubectl_context"

echo ""