#!/bin/bash

echo ""
echo "Creating Cloud Native Postgresql Database"

if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

helm install practicus-pg-db practicusai/practicus-pg-db \
  --namespace $PRT_NS \
  --values values-pg-db.yaml

echo ""
