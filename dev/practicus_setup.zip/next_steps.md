# What's next?  

- Configure user access and other settings using management console E.g.: 
  - https://practicus.my-company.com/console/admin
  - http://local.practicus.io/console/admin
  - ..
- Download Practicus AI app and start a dynamic Worker
- Although optional, we recommend you to install additional components such as persistent volume support  
- Install Kubernetes dashboard, if you do not already have access to a similar system
- Please check http://docs.practicus.ai/k8s-setup/ for more info
- Check the 'other' folder for helper scripts to install some optional components. 
