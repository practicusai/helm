#!/bin/bash

echo ""

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo""
echo "Analyzing istio"
istioctl analyze -n istio-system
istioctl analyze -n "$PRT_NS"

ISTIO_SERVICE_LB_HOST=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
ISTIO_SERVICE_LB_IP=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
ISTIO_INGRESS_HOST=$(kubectl -n istio-system get ingress istio-system -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
ISTIO_INGRESS_IP=$(kubectl -n istio-system get ingress istio-system -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

export ISTIO_SERVICE_LB_HOST
export ISTIO_SERVICE_LB_IP
export ISTIO_INGRESS_HOST
export ISTIO_INGRESS_IP

echo ""
echo "Locating Load Balancer host or IP address(es)"
echo ""
echo "You can define a DNS CNAME e.g. for practicus.company.com pointing to one of the below hosts"
echo " Istio service Load Balancer host: $ISTIO_SERVICE_LB_HOST"
echo " Istio ingress host: $ISTIO_INGRESS_HOST"
echo ""
echo "No host name? You can define a DNS A record e.g. for practicus.company.com pointing to one of the below IP addresses"
echo " Istio service Load Balancer IP: $ISTIO_SERVICE_LB_IP"
echo " Istio ingress IP: $ISTIO_INGRESS_IP"
echo ""

if [ -z "$ISTIO_INGRESS_HOST" ] && [ -z "$ISTIO_INGRESS_IP" ] && [ -z "$ISTIO_SERVICE_LB_HOST" ] && [ -z "$ISTIO_SERVICE_LB_IP" ]; then
  echo "************************************************************"
  echo "ISSUE DETECTED!"
  echo ""
  echo "No Istio ingress host or IP address found."
  echo "Potential reasons and solutions:"
  echo ""
  echo "1) This script failed."
  echo "Please run the below to see if you can locate EXTERNAL-IP for istio-ingressgateway"
  echo "  kubectl get service -n istio-system"
  echo "If EXTERNAL-IP column has a value, please use that to define the DNS as usual"
  echo ""
  echo "2) EXTERNAL-IP is missing or stuck at 'pending'"
  echo "This is common if you are running a vanilla Kubernetes environment or on bare metal"
  echo "No problem! You can install MetalLB to add a LoadBalancer"
  echo "Please read more here: https://metallb.universe.tf/#why"
  echo "After MetalLB installation, please run the below to uninstall and restart scripts"
  echo "  sh ./other/uninstall.sh"
  echo "************************************************************"
  echo ""
fi

