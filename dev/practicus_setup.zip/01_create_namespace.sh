#!/bin/bash

echo ""
echo "Creating kubernetes namespace."
current_kubectl_context=$(kubectl config current-context)
echo "Current kubectl context : $current_kubectl_context"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

kubectl create namespace "$PRT_NS"

echo ""