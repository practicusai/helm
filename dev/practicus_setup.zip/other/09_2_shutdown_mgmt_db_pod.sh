#!/bin/bash

echo "THIS SCRIPT IS REQUIRED ONLY IF YOU DISABLED DB AUTO MIGRATION"

echo ""
echo "Stopping Practicus AI Management Database configuration pod"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

helm uninstall prt-migrate-console-db --namespace $PRT_NS

echo ""