import os
import psycopg
from psycopg import sql


def create_practicus_db():
    # Database connection details
    # host = "prt-db-pg-1-rw.prt-ns.svc.cluster.local"
    host = os.getenv("PG_SERVER_HOST", None)
    assert host, "PG_SERVER_HOST env variable is not defined"
    port = os.getenv("PG_SERVER_PORT", "5432")
    admin_user = os.getenv("PG_SERVER_ADMIN", None)
    assert admin_user, "PG_SERVER_USER env variable is not defined"
    admin_password = os.getenv("PG_SERVER_ADMIN_PWD", None)
    assert admin_password, "PG_SERVER_ADMIN_PWD env variable is not defined"
    db_name = os.getenv("PG_SERVER_NEW_DB", None)
    assert db_name, "PG_SERVER_NEW_DB env variable is not defined"
    new_user = os.getenv("PG_SERVER_NEW_USER", None)
    assert new_user, "PG_SERVER_NEW_USER env variable is not defined"
    new_user_password = os.getenv("PG_SERVER_NEW_USER_PWD", None)
    assert new_user_password, "PG_SERVER_NEW_USER_PWD env variable is not defined"

    print(
        f"Creating PostgreSQL database:\n"
        f"PG_SERVER_HOST: {host}\n"
        f"PG_SERVER_PORT: {port}\n"
        f"PG_SERVER_ADMIN: {admin_user}\n"
        f"PG_SERVER_ADMIN_PWD: ********\n"
        f"PG_SERVER_NEW_DB: {db_name}\n"
        f"PG_SERVER_NEW_USER: {new_user}\n"
        f"PG_SERVER_NEW_USER_PWD: ********\n"
        f""
    )

    conn = psycopg.connect(host=host, port=port, user=admin_user, password=admin_password, dbname="postgres")
    try:
        conn.autocommit = True
        cur = conn.cursor()

        # Check if the database already exists
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s;", (db_name,))
        db_exists = cur.fetchone()

        if not db_exists:
            # Create the new database if it doesn't exist
            cur.execute(sql.SQL("CREATE DATABASE {};").format(sql.Identifier(db_name)))
            print(f"Database '{db_name}' created.")
        else:
            print(f"Database '{db_name}' already exists.")

        # Check if the admin_user already exists
        cur.execute("SELECT 1 FROM pg_roles WHERE rolname = %s;", (new_user,))
        user_exists = cur.fetchone()

        if user_exists:
            # Drop the admin_user if it exists
            print(f"User '{new_user}' already exists.")
        else:
            # Create the new admin_user with the specified admin_password
            cur.execute(
                sql.SQL("CREATE USER {} WITH PASSWORD %s;").format(sql.Identifier(new_user)), [new_user_password]
            )
            print(f"User '{new_user}' created.")

        cur.close()
    finally:
        conn.close()

    conn = psycopg.connect(host=host, port=port, user=admin_user, password=admin_password, dbname=db_name)
    try:
        sql_commands = ["GRANT USAGE ON SCHEMA public TO PUBLIC;", f"GRANT ALL ON SCHEMA public TO {new_user};"]
        with conn:
            with conn.cursor() as cursor:
                for command in sql_commands:
                    # print(f"Executing: {command}")
                    cursor.execute(command)
        print("Permissions granted successfully.")

    finally:
        conn.close()


if __name__ == "__main__":
    create_practicus_db()
