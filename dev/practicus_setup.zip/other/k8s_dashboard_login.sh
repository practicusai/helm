#!/bin/bash

echo "Generating a dashboard access token for 90 days and copying to clipboard"
kubectl -n kubernetes-dashboard create token dashboard-admin-user \
  --duration=2160h > dashboard-token.txt

echo "Generated token:"
echo ""
cat dashboard-token.txt
echo ""
echo ""
echo "Copied token to clipboard"
pbcopy < dashboard-token.txt
rm dashboard-token.txt

echo "Opening dashboard at:"
echo "http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/"

echo ""
open "http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/"
echo "Paste the access token at login page."

echo "Starting proxy to kubectl"
kubectl proxy

echo "No login page? Make sure you ran kubectl proxy first"