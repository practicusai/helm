#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Enabling Tracing with Istio"
echo "** Please make sure telemetry service URL in the .yaml file is correct **"

if [ -z "$PRT_ISTIO_GATEWAY_SERVICE_TYPE" ]; then
    PRT_ISTIO_GATEWAY_SERVICE_TYPE=$(kubectl get service istio-ingressgateway \
        --namespace istio-system \
        --output jsonpath='{.spec.type}' 2>/dev/null)
fi

if [ -z "$PRT_ISTIO_GATEWAY_SERVICE_TYPE" ]; then
    echo "ERROR: Could not determine the existing Istio ingress gateway service type."
    exit 1
fi

istioctl install \
    -f istio_operator.yaml \
    --set values.gateways.istio-ingressgateway.type="$PRT_ISTIO_GATEWAY_SERVICE_TYPE"

echo "Configuration complete. To verify you can view istio config map in istio-system namespace."

echo ""
