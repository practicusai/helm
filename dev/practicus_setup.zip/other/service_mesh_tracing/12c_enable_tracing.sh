#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Enabling Tracing with Istio"
echo "** Please make sure telemetry service URL in the .yaml file is correct **"
istioctl install -f istio_operator.yaml

echo "Configuration complete. To verify you can view istio config map in istio-system namespace."

echo ""
