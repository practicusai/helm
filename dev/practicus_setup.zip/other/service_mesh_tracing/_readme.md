# Service Mesh Tracing

In addition to model hosting, application hosting level tracing, you can also enable tracing at the service mesh level.

By doing so, the application level traces can be embedded into service mesh in/out traffic tracing and you can troubleshoot mesh level issues.

Important: This is a service mesh level change and applies to all istio traffic.
