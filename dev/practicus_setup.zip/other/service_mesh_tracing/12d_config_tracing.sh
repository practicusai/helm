#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Configuring Tracing with Istio"
echo "** Please make sure telemetry config in the .yaml file is correct **"
kubectl apply -f istio_telemetry.yaml

echo "Configuration complete. To verify you can view prt-ingress-tracing Telemetry CRD in istio-system namespace."

echo ""
