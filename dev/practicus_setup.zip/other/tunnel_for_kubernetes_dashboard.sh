#!/bin/bash

echo "Starting kubectl proxy for kubernetes dashboard"

kubectl proxy