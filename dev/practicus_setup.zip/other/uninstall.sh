#!/bin/bash

echo ""
echo "**********************************************************"
echo " CAUTION!"
echo "   All components including Istio will be uninstalled."
echo "   All related namespaces will be deleted."
echo "**********************************************************"
echo ""
echo "Please hit enter to continue"
read -r

echo ""
echo "Current kubectl context is *** $(kubectl config current-context) ***"
echo "Please verify this is the correct Kubernetes cluster and hit enter to continue"
read -r

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo ""
echo "Starting to uninstall all components including optional ones"
echo ""

echo ""
echo "Uninstalling Admin Console"
helm uninstall practicus-console --namespace $PRT_NS

echo ""
echo "Uninstalling Simple Object Storage"
helm uninstall practicus-simpleobj --namespace $PRT_NS

echo ""
echo "Deleting namespace: $PRT_NS"
kubectl delete namespace $PRT_NS

echo ""
echo "Uninstalling Istio"
istioctl uninstall --purge -y

echo ""
echo "Deleting istio-system namespace"
kubectl delete namespace istio-system

echo ""
echo "Completed uninstalling"
echo ""
