#!/bin/bash

echo "THIS SCRIPT IS REQUIRED ONLY IF YOU DISABLED DB AUTO MIGRATION"

echo ""
echo "Configuring Practicus AI Management Database"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

helm install prt-migrate-console-db practicusai/practicus-migrate-console-db \
  --namespace $PRT_NS \
  --set advanced.imagePullPolicy=Always \
  --values ./values.yaml

echo ""
