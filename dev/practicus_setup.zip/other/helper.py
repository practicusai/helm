import base64
import os
import sys
from pathlib import Path
from typing import Tuple
from uuid import uuid4
import certifi


def get_pem_contents(pem_path: str) -> Tuple[bytes, str, str]:
    if not os.path.exists(pem_path):
        print(f"Error: {pem_path} file doesn't exist. Please generate openssl keys first",
              file=sys.stderr)
        exit(1)
    with open(pem_path, "rt") as pem_file:
        pem_data = pem_file.read()
    pem_data_encoded = pem_data.encode("utf-8")
    pem_data_b64_str = str(base64.b64encode(pem_data_encoded), "utf-8")
    return pem_data_encoded, pem_data, pem_data_b64_str


if __name__ == '__main__':
    try:
        from jwcrypto import jwt, jwk
    except:
        print("Could not import jwcrypto library. Please install using the below", file=sys.stderr)
        print("pip3 install jwcrypto")
        exit(1)

    working_dir = Path(os.path.dirname(__file__)).parent
    secrets_dir = os.path.join(working_dir, "secrets")

    jwt_private_pem_path = os.path.join(secrets_dir, "jwt_private.pem")
    private_pem_data_encoded, _, private_pem_data_b64_str = get_pem_contents(jwt_private_pem_path)

    jwt_public_pem_path = os.path.join(secrets_dir, "jwt_public.pem")
    _, _, public_pem_data_b64_str = get_pem_contents(jwt_public_pem_path)

    istio_mtls_key_pem_path = os.path.join(secrets_dir, "ssl_key.pem")
    _, _, istio_mtls_key_pem_data_b64_str = get_pem_contents(istio_mtls_key_pem_path)

    istio_mtls_cert_pem_path = os.path.join(secrets_dir, "ssl_cert.pem")
    _, _, istio_mtls_cert_pem_data_b64_str = get_pem_contents(istio_mtls_cert_pem_path)

    ca_public_pem_path = os.path.join(secrets_dir, "ca_cert.pem")
    _, ca_public_pem_content, _ = get_pem_contents(ca_public_pem_path)

    include_mozilla = not str(os.getenv("PRT_SELF_SIGNED_CERT_INCLUDE_PUBLIC", "true")).lower() == "false"

    if include_mozilla:
        _, current_certifi_content, _ = get_pem_contents(certifi.where())
        final_cert = f"# Practicus AI Private CA\n{ca_public_pem_content}\n\n{current_certifi_content}"
    else:
        final_cert = ca_public_pem_content

    final_cert_b64_str = str(base64.b64encode(final_cert.encode("utf-8")), "utf-8")

    web_hash_salt_path = os.path.join(secrets_dir, "web_hash_salt.txt")
    web_hash_salt = f"{uuid4().hex}{uuid4().hex}"
    with open(web_hash_salt_path, "wt") as _f:
        _f.write(web_hash_salt)

    jwt_key = jwk.JWK.from_pem(private_pem_data_encoded)

    jwks_json = "{ \"keys\":[ " + jwt_key.export(private_key=False) + "]}"
    with open(os.path.join(secrets_dir, "jwks.json"), "wt") as f:
        f.write(jwks_json)

    print(f"Secret files are generated and written under: {secrets_dir}")

    values_yaml_path = os.path.join(working_dir, "values-keys.yaml")
    with open(values_yaml_path, "wt") as f:
        jwt_yaml = (f"# You can update this file and the generated keys manually, or by running the helper scripts to re-create them\n\n" 
                    f"jwt:\n" 
                    f"  privateKeyBase64: {private_pem_data_b64_str}\n" 
                    f"  publicKeyBase64: {public_pem_data_b64_str}\n" 
                    f"  jwks: '{jwks_json}'\n\n")
        f.write(jwt_yaml)

        istio_yaml = (f"istio:\n" 
                      f"  # The below are primarily used to encrypt Kubernetes pod-to-pod internal traffic (mutual TLS).\n" 
                      f"  # If you want to ingest https traffic from outside Kubernetes,\n"
                      f"  #   e.g. when you do not have a load balancer with SSL termination,\n" 
                      f"  #   please create new SSL certificates with your CA first,  \n" 
                      f"  #   and replace the below after base64 encoding them.\n" 
                      f"  mtlsKeyBase64: {istio_mtls_key_pem_data_b64_str}\n" 
                      f"  mtlsCertBase64: {istio_mtls_cert_pem_data_b64_str}\n\n")
        f.write(istio_yaml)

        web_hash_salt_b64 = str(base64.b64encode(bytes(web_hash_salt, "utf-8")), "utf-8")
        web_hash_salt_yaml = (f"session:\n"
                              f"  webHashSaltBase64: {web_hash_salt_b64}\n\n")
        f.write(web_hash_salt_yaml)

        ca_public_pem_yaml = (f"certificateAuthority:\n"
                              f"  # Self-created CA merged to the Mozilla public certificates (via Python certifi) \n"
                              f"  # The below is not needed if you have a load balancer with SSL termination, or, \n"
                              f"  #   you already embedded your private CA's to the Kubernetes cluster. \n"
                              f"  # If you want to use your own CA *and* cannot install it at cluster level, \n"
                              f"  #   please replace the below with your own CA public key. \n"
                              f"  publicKeyBase64: {final_cert_b64_str}\n")
        f.write(ca_public_pem_yaml)

    print(f"Secret values yaml file is generated and written to {values_yaml_path}")
