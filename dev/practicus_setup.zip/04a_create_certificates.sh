#!/bin/bash

clear
echo
echo "Creating certificates"
echo

if [ -z "$PRT_CERT_CA_CN" ] || [ -z "$PRT_DOMAIN_CN" ]; then
    echo "ERROR: Please define the common names (CN) for CA. E.g."
    echo '  export PRT_CERT_CA_CN="My Company Inc."'
    echo
    echo "And local or internet domain common name (CN). E.g."
    echo "  export PRT_DOMAIN_CN=practicus.mycompany.com   or for local domains,"
    echo "  export PRT_DOMAIN_CN=practicus.mycompany.local"
    echo
    exit 1
fi

echo
echo "CA CN                   : $PRT_CERT_CA_CN"
echo "Certificate Domain CN   : *.$PRT_DOMAIN_CN"
echo "Domain Subject Alt name :   $PRT_DOMAIN_CN"
echo "Secrets directory       : $PWD/secrets"
if [ -z "$PRT_SELF_SIGNED_CERT" ] || [ "$PRT_SELF_SIGNED_CERT" = true ]; then
    export PRT_SELF_SIGNED_CERT=true
    echo
    echo "********************************************************************************************"
    echo "IMPORTANT NOTE ON SELF-SIGNED CERTIFICATES "
    echo "********************************************************************************************"
    echo "You are using self-signed certificates, and this is OK if:"
    echo "- You are terminating SSL (https traffic) on a load balancer outside of kubernetes, "
    echo "  and the self-signed certificates are only used to secure traffic inside kubernetes (mTls)."
    echo "  If this is the case, you can safely ignore the below content."
    echo "- OR, Practicus AI will handle https traffic, you do NOT have a Certificate Authority (CA), "
    echo "  and the end users can install a certificate on their laptops for https to work."
    echo "  Note: Some services such as VS Code will NOT work with http, and skipping the "
    echo "  self-signed certificate warnings on a browser might still cause some issues."
    echo
    echo "If you would like to use your own CA instead of self-signed certs:"
    echo "1) Ask your Certificate Admin for 'ssl_cert.pem' and 'ssl_key.pem' files that satisfies "
    echo "   Subject Alternative Name (SAN)"
    echo "   DNS : $PRT_DOMAIN_CN"
    echo "   DNS : *.$PRT_DOMAIN_CN"
    echo "2) Copy 'ssl_cert.pem' and 'ssl_key.pem' files under: $PWD"
    echo "3) Execute 'export PRT_SELF_SIGNED_CERT=false' before running this script."
    echo "********************************************************************************************"
else
    echo "You are using your own Certificate Authority (CA)."
fi

echo
echo "Please hit enter to confirm or CTRL+C to quit."
read -r

cd "$(dirname "$0")" || exit

echo "Cleaning up existing scripts"
rm -rf secrets
mkdir secrets

echo "Creating certificates for JWT (JSON Web Token, does NOT need a CA)"
openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout ./secrets/jwt_private.pem -subj "/CN=$PRT_DOMAIN_CN" > ./secrets/openssl.msg.txt

openssl rsa -in ./secrets/jwt_private.pem \
  -outform PEM -pubout -out ./secrets/jwt_public.pem > ./secrets/openssl.msg.txt

if [ "$PRT_SELF_SIGNED_CERT" = true ]; then
    echo "Creating self-signed certificates"

    echo "Creating Certificate Authority (CA) for $PRT_CERT_CA_CN"
    openssl genrsa -out ./secrets/ca_key.pem 4096
    openssl req -x509 -new -nodes -key ./secrets/ca_key.pem -sha256 -days 3650 \
        -out ./secrets/ca_cert.pem -subj "/CN=$PRT_CERT_CA_CN"

    echo "Creating SSL private key"
    openssl genrsa -out ./secrets/ssl_key.pem 4096

    echo "Creating CSR for SSL certificates"
    openssl req -new -sha256 -key ./secrets/ssl_key.pem -out ./secrets/server.csr -subj "/CN=*.$PRT_DOMAIN_CN"

    # Important! Chrome and many other systems will fail if certificate validity is over 398 days.
    SSL_CERT_VALIDITY_DAYS=397
    echo "Signing SSL certificates with CA for $SSL_CERT_VALIDITY_DAYS days"
    openssl x509 -req -in ./secrets/server.csr -CA ./secrets/ca_cert.pem \
        -CAkey ./secrets/ca_key.pem -CAcreateserial -out ./secrets/ssl_cert.pem -days $SSL_CERT_VALIDITY_DAYS -sha256 \
        -extfile <(printf "subjectAltName=DNS:%s,DNS:%s" "*.$PRT_DOMAIN_CN" "$PRT_DOMAIN_CN")

    echo
    echo "Completed setting up certificates."
    echo "IMPORTANT: Your certificate is valid for $SSL_CERT_VALIDITY_DAYS days (if self-signed)."
    echo "           You *MUST* renew ssl_cert.pem before it expires, to prevent a system-wide disruption."
    echo
else
    echo "Using certificates created by your own CA for https traffic."

    if [ ! -f "./ssl_cert.pem" ] || [ ! -f "./ssl_key.pem" ]; then
        echo "ERROR: You chose to use your own CA by setting PRT_SELF_SIGNED_CERT=false "
        echo "       but 'ssl_cert.pem' and 'ssl_key.pem' could not be located under $PWD"
        exit 1
    fi

    cp ./ssl_cert.pem ./secrets/ssl_cert.pem
    cp ./ssl_key.pem ./secrets/ssl_key.pem
    echo
    echo "Completed setting up certificates."
fi
