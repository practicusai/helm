#!/bin/bash

clear
echo
echo "Creating certificates"
echo

if [[ -z "$PRT_CERT_CA_CN" || -z "$PRT_DOMAIN_CN" ]]; then
    echo "ERROR: Please define the common names (CN) for CA. E.g."
    echo '  export PRT_CERT_CA_CN="My Company Inc."'
    echo
    echo "And local or internet domain common name (CN). E.g."
    echo "  export PRT_DOMAIN_CN=practicus.mycompany.com   or for local domains,"
    echo "  export PRT_DOMAIN_CN=practicus.mycompany.local"
    echo
    exit 1
fi

echo
echo "CA CN                   : $PRT_CERT_CA_CN"
echo "Certificate Domain CN   : *.$PRT_DOMAIN_CN"
echo "Domain Subject Alt name :   $PRT_DOMAIN_CN"
echo "Secrets directory       : $PWD/secrets"
echo
echo "Please hit enter to confirm or CTRL+C to quit."
read -r

cd "$(dirname "$0")" || exit

echo "Cleaning up existing scripts"
rm -rf secrets
mkdir secrets

echo "Creating certificates for JWT (JSON Web Token, does not need CA)"
openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout ./secrets/jwt_private.pem -subj "/CN=$PRT_DOMAIN_CN" > ./secrets/openssl.msg.txt

openssl rsa -in ./secrets/jwt_private.pem \
  -outform PEM -pubout -out ./secrets/jwt_public.pem > ./secrets/openssl.msg.txt


mkdir secrets
echo "Creating Certificate Authority (CA) for $PRT_CERT_CA_CN"
openssl genrsa -out ./secrets/ca_key.pem 4096
openssl req -x509 -new -nodes -key ./secrets/ca_key.pem -sha256 -days 3650 \
    -out ./secrets/ca_cert.pem -subj "/CN=$PRT_CERT_CA_CN"

echo "Creating SSL private key"
openssl genrsa -out ./secrets/ssl_key.pem 4096

echo "Creating CSR for SSL certificates"
openssl req -new -sha256 -key ./secrets/ssl_key.pem -out ./secrets/server.csr -subj "/CN=*.$PRT_DOMAIN_CN"

echo "Signing SSL certificates with CA"
openssl x509 -req -in ./secrets/server.csr -CA ./secrets/ca_cert.pem \
    -CAkey ./secrets/ca_key.pem -CAcreateserial -out ./secrets/ssl_cert.pem -days 3650 -sha256 \
    -extfile <(printf "subjectAltName=DNS:%s,DNS:%s" "*.$PRT_DOMAIN_CN" "$PRT_DOMAIN_CN")

echo
echo "Completed creating certificates."
echo
echo "IMPORTANT: Please carefully store and secure the private keys under ./secrets folder."
echo