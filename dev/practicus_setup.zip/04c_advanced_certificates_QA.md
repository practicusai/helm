# Are self-created certificates used for https traffic?
- Only if you do *not* use a load balancer with SSL termination, such as AWS ALB. 
- In this case traffic enters the istio gateway as https, and SSL certificates are used. 
- Note: Practicus AI recommends using a load balancer with SSL termination for all Kubernetes workloads.

# Can I use self-signed certificates for Enterprise Single Sign-On (SSO)?
- Yes, but *only after* installing Certificate Authority (CA) public keys on Kubernetes pods. This is an advanced step.
- For dev/test/poc scenarios, we recommend using http for all traffic including SSO. 
- Please see below "Adding CA in Kubernetes" section to learn more.

# Can end users bypass browser warnings for self-signed certificates?
Yes, but *only after* you install CA public keys on end user computers.

# Can I use my own CA bundle?
Yes, please follow the below steps:
1) Run the certificate scripts as usual, so non-SSL related keys are also created.
2) Replace SSL keys under values-keys.yaml file, "istio" section.
3) Add the CA following steps under "Adding CA in Kubernetes" section.

# Will I be able to use public https sites after I use my CA bundle?
Yes, IF you follow the below steps:
1) Get current public certificates

```shell
export CERTIFI_PATH=$(python3 -c "import certifi; print(certifi.where())")
echo "Current Python certifications path $CERTIFI_PATH"
```

2) Copy the current python certificates file, add your own certificate to it and base64
3) Add the new CA bundle following steps under "Adding CA in Kubernetes" section.

# Appendix

## Adding a CA in Kubernetes
If you do not use a global CA such as DigiCert or Let's encrypt you have to get Kubernetes pods trust your private CA.

### Option 1) (Recommended) Adding your private CA to Kubernetes "cluster-wide"
You can perform Kubernetes distro specific steps to get your pods trust the private CA.  
- AWS EKS: https://docs.aws.amazon.com/privateca/latest/userguide/PcaKubernetes.html
- Azure AKS: https://learn.microsoft.com/en-us/azure/aks/custom-certificate-authority
- Google GKE: https://cloud.google.com/kubernetes-engine/docs/how-to/access-private-registries-private-certificates
- Red Hat OpenShift: https://docs.openshift.com/container-platform/4.15/security/certificate_types_descriptions/service-ca-certificates.html
- Suse Rancher: https://ranchermanager.docs.rancher.com/getting-started/installation-and-upgrade/installation-references/helm-chart-options#additional-trusted-cas

### Option 2) Adding your private CA to Kubernetes pods manually
A less ideal alternative method of installing CA to pods is to do the following:

1) Save the CA as a Kubernetes secret
2) Mount it as a volume to pods
3) Install the CA each time the pod starts, with or without an init container.

- Practicus AI can do the above for *some* workloads, and for others you will have to manually perform the steps. 
- Please note: Practicus AI does not recommend this method due to security concerns since the pods need to run with root privileges. 

- To use your own CA *and* let Practicus AI embed it to some pods, please do the following:
1) Run the certificate scripts as usual
2) Replace the CA public certificate under values-keys.yaml file, certificateAuthority section.
