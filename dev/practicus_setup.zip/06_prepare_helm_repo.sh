#!/bin/bash

echo ""
echo "Adding practicusai helm repo"
helm repo add practicusai https://practicusai.github.io/helm || echo "Practicus AI helm repo already added"

echo "Updating all helm repos on your computer"
helm repo update

echo "You can view available charts in practicusai repo running the below:"
echo "helm search repo practicusai"
echo ""