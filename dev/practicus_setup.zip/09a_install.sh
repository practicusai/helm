#!/bin/bash

cd "$(dirname "$0")" || exit

echo ""
echo "Installing Practicus AI"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

helm install practicus-console practicusai/practicus-console \
  --namespace "$PRT_NS" \
  --values values-keys.yaml \
  --values values.yaml

echo ""
echo "Waiting until pods are ready in $PRT_NS namespace"

kubectl wait --for=condition=ready --timeout=60s pod --all -n "$PRT_NS"

echo ""
