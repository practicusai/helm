#!/bin/bash

echo "This is a placeholder for actions specifically required for a particular Kubernetes environment"
echo "Please check sub folders to see if your cluster needs a specific task"