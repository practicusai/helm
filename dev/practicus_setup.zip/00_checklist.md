# Getting Started

Before you begin, please make sure you review the below list.

## Pre-requisites

- A Kubernetes cluster
- kubectl installed, and using the desired context (your target kubernetes cluster) 
- helm installed 
- istioctl installed
- Practicus AI Enterprise key 

Please check http://docs.practicus.ai/k8s-setup/ if you need help preparing for the above components.

## Optional 

- If you are using a kubernetes namespace other than the default prt-ns, please define using before running scripts: 
  - export PRT_NS=add_k8s_namespace_here

## Platform specific scripts 

Some scripts in this folder are platform specific, E.g. only for AWS, GCP, OpenShift (ocp) etc. Please only run the script for your platform and ignore others. If a file has no extension, e.g. _ocp.sh it is supported on all other Kubernetes platforms.         


