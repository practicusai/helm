#!/bin/bash

echo ""
echo "Creating sample S3 compatible Object Storage"

echo "** IMPORTANT ** Sample object storage should only be used for testing or PoC scenarios"

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

kubectl create namespace $PRT_NS || echo "$PRT_NS already exists"

helm install practicus-sampleobj practicusai/practicus-sampleobj \
  --namespace $PRT_NS \
  --values values-minio.yaml

echo ""
