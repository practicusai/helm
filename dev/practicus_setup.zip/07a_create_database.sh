#!/bin/bash

clear
echo ""
echo "Practicus AI PostgreSQL Database Creation"
echo
echo "Note: You can skip this step if you installed PostgreSQL Server using previous scripts."
echo "The DB server installation already creates the practicus_console database with necessary permissions."
echo
echo "Please hit enter to continue or CTRL+C to quit."
read -r


if [ -z "$PG_SERVER_HOST" ] || [ -z "$PG_SERVER_ADMIN" ] || [ -z "$PG_SERVER_ADMIN_PWD" ] \
  || [ -z "$PG_SERVER_NEW_DB" ] || [ -z "$PG_SERVER_NEW_USER" ] || [ -z "$PG_SERVER_NEW_USER_PWD" ]; then
    echo "Please define DB server, admin user and new database info. E.g."
    echo " export PG_SERVER_HOST=some-database-address"
    echo " export PG_SERVER_PORT=5432"
    echo " export PG_SERVER_ADMIN=postgres"
    echo " export PG_SERVER_ADMIN_PWD=practicus_ai"
    echo " export PG_SERVER_NEW_DB=prt_console"
    echo " export PG_SERVER_NEW_USER=console_db_owner"
    echo " export PG_SERVER_NEW_USER_PWD=console_db_pwd"
    exit 1
fi

clear
echo "Starting to create Practicus AI PostgreSQL Database with the below values:"
echo
echo "  PG_SERVER_HOST: $PG_SERVER_HOST"
echo "  PG_SERVER_PORT: $PG_SERVER_PORT"
echo "  PG_SERVER_ADMIN: $PG_SERVER_ADMIN"
echo "  PG_SERVER_ADMIN_PWD: ********"
echo "  PG_SERVER_NEW_DB: $PG_SERVER_NEW_DB"
echo "  PG_SERVER_NEW_USER: $PG_SERVER_NEW_USER"
echo "  PG_SERVER_NEW_USER_PWD: ********"
echo
echo "Please hit enter to confirm or CTRL+C to quit."
read -r

if [ -d venv ]; then
  echo "Existing Python virtual env found for this script. Version:"
  ./venv/bin/python3 --version || fail "Python3 venv not found, please install python first. Exiting script."
else
  echo "Current system Python version is:"
  python3 --version || fail "Python3 not found, please install python first. Exiting script."

  echo "Creating a temporary Python virtual environment for libraries needed during setup"
  python3 -m venv ./venv
fi

echo "Installing supporting database libraries"
./venv/bin/python3 -m pip install --upgrade pip
./venv/bin/python3 -m pip install psycopg2-binary

echo "Starting database creation script."
echo

./venv/bin/python3 other/create_db.py

echo
echo "Completed creating database."
