#!/bin/bash

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "Analyzing Kubernetes for Istio compatibility"
istioctl x precheck

echo ""
echo "Installing Istio"

if [ -z "$PRT_ISTIO_GATEWAY_SERVICE_TYPE" ]; then
    PRT_ISTIO_GATEWAY_SERVICE_TYPE=$(kubectl get service istio-ingressgateway \
        --namespace istio-system \
        --output jsonpath='{.spec.type}' 2>/dev/null)
fi

if [ -z "$PRT_ISTIO_GATEWAY_SERVICE_TYPE" ]; then
    KUBERNETES_PROVIDER_ID=$(kubectl get nodes \
        --output jsonpath='{.items[0].spec.providerID}' 2>/dev/null)
    case "$KUBERNETES_PROVIDER_ID" in
        aws://*) PRT_ISTIO_GATEWAY_SERVICE_TYPE=NodePort ;;
        *) PRT_ISTIO_GATEWAY_SERVICE_TYPE=LoadBalancer ;;
    esac
fi

case "$PRT_ISTIO_GATEWAY_SERVICE_TYPE" in
    ClusterIP|NodePort|LoadBalancer) ;;
    *)
        echo "ERROR: Invalid PRT_ISTIO_GATEWAY_SERVICE_TYPE: $PRT_ISTIO_GATEWAY_SERVICE_TYPE"
        echo "Expected ClusterIP, NodePort, or LoadBalancer."
        exit 1
        ;;
esac

export PRT_ISTIO_GATEWAY_SERVICE_TYPE
echo "Istio ingress gateway service type: $PRT_ISTIO_GATEWAY_SERVICE_TYPE"
istioctl install \
    --set profile=default \
    --set values.gateways.istio-ingressgateway.type="$PRT_ISTIO_GATEWAY_SERVICE_TYPE" \
    -y

echo "Analyzing Istio"
istioctl analyze -n istio-system
istioctl analyze -n "$PRT_NS"

echo ""
