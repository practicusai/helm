#!/bin/bash

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "Analyzing Kubernetes for Istio compatibility"
istioctl x precheck

echo ""
echo "Installing Istio"
istioctl install --set profile=default -y

echo "Analyzing Istio"
istioctl analyze -n istio-system
istioctl analyze -n "$PRT_NS"

echo ""