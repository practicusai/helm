# Practicus AI on MicroK8s installation notes

You can use MicroK8s on a standalone Ubuntu server or WSL2 on Windows.

## Install MicroK8s 

- Install MicroK8s on your selected OS. 
- Note: For MacOS, we recommend the K8s that comes with Docker Desktop.

### Bare bones Ubuntu 

Install using steps: https://microk8s.io/docs/getting-started

### Install MicroK8s on WSL2 (Windows)

Install using steps: https://microk8s.io/docs/install-wsl2

## Enable services using snap

- Using the above guides, enable 'dns, storage, dashboard, metallb' services  
- You can also enable one of Practicus AI requirements 'istio' using snap.

## Setup Practicus AI

Follow the steps as usual in parent directory.

## Accessing Practicus AI management console

### Ubuntu

- You can access Practicus AI management console using http://local.practicus.io/console/admin inside Ubuntu. 
- 'local.practicus.io' points to 127.0.0.1
- In oder to access from outside the server, you will have to assign and IP and a DNS address e.g. practicus.mycompany.com 
- If you use a DNS address other than local.practicus.io, please make sure the certificate CN that you assign in the parent folder scripts use the DNS, potentially with a wildcard, e.g., *.mycompany.com 

### WSL2 

- For a local test environment, Practicus AI installs on the default 'local.practicus.io' this always points to 127.0.0.1
- If you are using WSL2 on Windows, please test using below:

1) On WSL2 run: 'curl local.practicus.io' The endpoint should be responsive with http response 200. 
2) On your Windows desktop, try logging in to the management console using http://local.practicus.io/console/admin
3) Not working? 
- Check istio-ingressgateway External IP section using the command "kubectl -n istio-system get service istio-ingressgateway". 
- The IP address might remain in 'pending' state.
- Enable MetalLb for your cluster. To enable MetalLB, you need to run the following command -> microk8s enable metallb
- At this step, it will ask you for an IP range
- You should provide an IP range based on the IP address of your WSL machine
- You can find the IP address of your WSL machine by using the "ipconfig" command in the Command Prompt
- If your WSL2 IP like 172.28.210.5, you will need to provide a range like 172.28.210.100-172.28.210.200.
- You can view the assigned IP address using the command "kubectl -n istio-system get service istio-ingressgateway". Check for External-IP section.
- Edit Windows hosts file under C:\Windows\System32\drivers\etc\hosts using an elevated (admin) Notepad. Add anew line: _assigned_ip_address_ local.practicus.io. 
4) Still not working? try port forwarding using kubectl. E.g. run 'kubectl -n prt-ns port-forward service/prt-svc-console 8000:8000'  While this is still running inside WSL2, open management console using 8000 port http://local.practicus.io:8000/console/admin

## Using Practicus AI app

- After you make sure the console is accessible, download and open Practicus AI app and in settings add the http://local.practicus.io (or http://local.practicus.io:8000 if you are port forwarding)
- If you would like to use https://, open settings > network tab and check "bypass SSL verification". You do not need this step if you are using a public SSL certificate, and not the self-signed certificates Practicus AI creates.  
