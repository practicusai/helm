# Practicus AI on minikube installation notes

Minikube on MacOS will not require any specific tasks. For Windows, please see the below.

- Upgrade to WSL2

- Install minikube using the below or similar guide
- https://gaganmanku96.medium.com/kubernetes-setup-with-minikube-on-wsl2-2023-a58aea81e6a3

- Install MetalLB and assign minikube ip address such as 192.168.49.2 (verify with minikube ip)
- https://kubebyexample.com/learning-paths/metallb/install

- Install istio, in the validation stage of the parent folder scripts, make sure external-ip is the IP you gave with MetalLB. 

- Point local.practicus.io to 192.168.49.2 using /etc/hosts 
- curl -vk 'http://local.practicus.io/console/admin' should work

The rest of the steps should be the same.