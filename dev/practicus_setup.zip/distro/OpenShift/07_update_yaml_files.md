# Openshift values.yaml notes

- If you add the below to values.yaml, Practicus AI will not use the default ubuntu (1000) user and let the Kubernetes cluster choose the user. This will allow OpenShift to run Practicus AI console and model hosting deployments with a random user id.

```yaml
advanced:
  console:
    securityContext:
      enabled: false
  modelHost:
    securityContext:
      enabled: false
  appHost:
    securityContext:
      enabled: false
```