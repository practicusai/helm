#!/bin/bash

echo "Some Practicus AI platform workloads require to run with the specific non-privileged ubuntu user (id 1000)"

echo ""
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "OpenShift - Adding non-root policy to prt-sa-wn service account"

oc adm policy add-scc-to-user nonroot -z prt-sa-wn -n "$PRT_NS"

# Alternative, non-root for all service accounts.
# oc adm policy add-scc-to-group non-root system:serviceaccounts:$PRT_NS
