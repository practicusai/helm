# OpenShift specific custom Certificate Authority (CA) Notes

- OpenShift can inject CA bundle using the below label
- config.openshift.io/inject-trusted-cabundle: "true" 
- In order to use this feature, you can set advanced.isOpenshift: true in values.yaml during Practicus AI Console installation

# IMPORTANT NOTE on public CA bundles:

- When you switch to using your own CA bundle, the current global root CA's (e.g. GlobalSign) will no longer be available.
- If Practicus AI workloads will access the internet, e.g. for "pip install" operations, you must merge global CA's 
  content with your private CA to a single file and have OpenShift to inject this bundle.
- Check the parent directory QA content to learn more.