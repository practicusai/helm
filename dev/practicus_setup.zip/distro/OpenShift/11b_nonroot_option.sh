#!/bin/bash

echo "ALTERNATIVE TO anyuid"
echo "Some Practicus AI platform workloads require to run with a specific non-privileged user id"

echo ""
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "OpenShift - Adding policy"

oc adm policy add-scc-to-user nonroot -z prt-sa-wn -n "$PRT_NS"

# Alternative, non-root for all service accounts.
# oc adm policy add-scc-to-group nonroot system:serviceaccounts:$PRT_NS
