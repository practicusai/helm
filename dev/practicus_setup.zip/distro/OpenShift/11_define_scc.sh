#!/bin/bash

echo "Some Practicus AI platform workloads require to run with the specific non-privileged OR sudo ubuntu user (id 1000)"

echo ""
if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

SA_PRIVILEGE="privileged"
# To remove users sudo access on workers (e.g. jupyter notebook) make the service account nonroot
# SA_PRIVILEGE="nonroot"

echo "OpenShift - Adding $SA_PRIVILEGE policy to prt-sa-wn service account for Workers"
if [ "$SA_PRIVILEGE" = "nonroot" ]; then
  echo "IMPORTANT: Advanced users will not have sudo access on Workers. For sudo, please change the script SA_PRIVILEGE to privileged."
else
  echo "IMPORTANT: Users will not be restricted. For a more locked-down / secure environment change the script SA_PRIVILEGE to nonroot."
fi

echo "Please hit enter to confirm or CTRL+C to quit."
read -r

oc adm policy add-scc-to-user $SA_PRIVILEGE -z prt-sa-wn -n "$PRT_NS"

# Alternative, non-root for all service accounts.
# oc adm policy add-scc-to-group non-root system:serviceaccounts:$PRT_NS
