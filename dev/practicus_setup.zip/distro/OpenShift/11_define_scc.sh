#!/bin/bash

echo "Some Practicus AI platform workloads require to run with the specific non-privileged OR sudo ubuntu user (id 1000)"

echo ""
if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

 # Non-default security context settings
echo "Assigning nonroot SCC to prt-sa-wn-restricted."
echo "  This service account is only used when admins force restricted access."
oc adm policy add-scc-to-user "nonroot" -z prt-sa-wn-restricted -n "$PRT_NS"

echo "Assigning privileged SCC to prt-sa-wn-privileged."
echo "  This service account is only used when admins allow privileged access."
echo "  It's primary purpose is to grant sudo access and build custom container images."
oc adm policy add-scc-to-user "privileged" -z prt-sa-wn-privileged -n "$PRT_NS"

# Default security context settings
DEFAULT_SA_PRIVILEGE="privileged"
# To remove users sudo access on workers by default, make the service account nonroot
# DEFAULT_SA_PRIVILEGE="nonroot"

echo "OpenShift - Adding $DEFAULT_SA_PRIVILEGE policy to primary service accounts for Workers"
if [ "$DEFAULT_SA_PRIVILEGE" = "nonroot" ]; then
  echo "IMPORTANT: Advanced users will not have sudo access on Workers. "
  echo "  For sudo, please change the script DEFAULT_SA_PRIVILEGE to 'privileged'"
  echo "  Or, lets admins grant access to privileged Workers selectively:"
  echo "  Admin console > Worker Sizes > define a new worker size > turn on 'Privileged'"
  echo "  and then grant access for this Worker size to groups / users"
  echo "Please hit enter to confirm or CTRL+C to quit."
  read -r
fi

echo "Assigning $DEFAULT_SA_PRIVILEGE SCC to primary Worker service account prt-sa-wn"
oc adm policy add-scc-to-user $DEFAULT_SA_PRIVILEGE -z prt-sa-wn -n "$PRT_NS"
echo "Assigning $DEFAULT_SA_PRIVILEGE SCC to auto-distributed Worker service account prt-sa-wn-distributed"
oc adm policy add-scc-to-user $DEFAULT_SA_PRIVILEGE -z prt-sa-wn-distributed -n "$PRT_NS"
echo "Assigning $DEFAULT_SA_PRIVILEGE SCC to Workspace service account prt-sa-wsp"
oc adm policy add-scc-to-user $DEFAULT_SA_PRIVILEGE -z prt-sa-wsp -n "$PRT_NS"
