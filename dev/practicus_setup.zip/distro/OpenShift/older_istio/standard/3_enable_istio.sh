#!/bin/bash

echo ""
if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "OpenShift - Adding policy"
oc adm policy add-scc-to-group anyuid system:serviceaccounts:$PRT_NS

# Note: if sudo access will not be needed for advanced scenarios, adding nonroot scc will also work using the below
# oc adm policy add-scc-to-group nonroot system:serviceaccounts:$PRT_NS

echo "OpenShift - Defining network attachment for CNI"
cat <<EOF | oc -n $PRT_NS create -f -
apiVersion: "k8s.cni.cncf.io/v1"
kind: NetworkAttachmentDefinition
metadata:
  name: istio-cni
EOF

echo ""
