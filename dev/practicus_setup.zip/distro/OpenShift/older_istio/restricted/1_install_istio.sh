#!/bin/bash

echo ""
echo "Installing Istio for ** Red Hat OpenShift **"

echo "OpenShift - Adding policy"

oc adm policy add-scc-to-group nonroot system:serviceaccounts:istio-system

echo "OpenShift - Installing Istio using CNI"
istioctl install -f istio-cni.yaml -y

echo "OpenShift - Exposing port"
oc -n istio-system expose svc/istio-ingressgateway --port=http2

echo ""