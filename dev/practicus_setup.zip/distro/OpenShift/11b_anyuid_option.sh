#!/bin/bash

echo "Practicus AI works with the least privilege principle for most workloads"
echo "For the below activities,  Practicus AI namespace workloads require root access"
echo "- Power users will require sudo access to be able to install (e.g. via apt get)"
echo "- Instant batch AI prediction (prediction without model deployment APIs) require advanced networking inside a pod"
echo "- Cloud Native PostgreSQL require privileged access"
echo "- All other workloads such as console admin, model hosting etc. work fully unprivileged"

echo ""
if [[ -z "$PRT_NS" ]]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo "OpenShift - Adding policy"

oc adm policy add-scc-to-user anyuid -z prt-sa-wn -n "$PRT_NS"

# Alternative, non-root for all service accounts.
# oc adm policy add-scc-to-group anyuid system:serviceaccounts:$PRT_NS
