#!/bin/bash

if [ -z "$PRT_NS" ]; then
    export PRT_NS=prt-ns
    echo "PRT_NS env variable is not defined, will use the default $PRT_NS"
fi

echo ""
echo "Installing Istio for ** Red Hat OpenShift **"
echo "Check latest OCP install instructions from:"
echo "  https://istio.io/latest/docs/setup/platform-setup/openshift/"

echo "OpenShift - Installing Istio"
istioctl install --set profile=openshift -y

echo "OpenShift - Exposing port"
oc -n istio-system expose svc/istio-ingressgateway --port=http2

echo "Analyzing Istio"
istioctl analyze -n istio-system
istioctl analyze -n "$PRT_NS"

echo ""
