# Azure Postgresql database
- We strongly suggest you to use the managed PostgreSQL database on Azure
- Guide: https://learn.microsoft.com/en-us/azure/postgresql/flexible-server/quickstart-create-server-portal
- Set Server parameter require_secure_transport OFF
