# Azure AKS Istio
- Azure AKS offers an Istio add-on which is *NOT* fully compatible with the original (upstream) Istio.
- At the time of this writing, Practicus AI does *NOT* support AKS Istio add-on.
