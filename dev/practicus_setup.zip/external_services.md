# Practicus AI External Services

Practicus AI external services such as Airflow and Mlflow are optional but highly recommended services.

To install please download setup guide from: 
https://practicusai.github.io/helm/practicus_setup_ext_svc.zip 
