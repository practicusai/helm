# Practicus AI Add-on Services

Installing Practicus AI add-on services such as Airflow and Mlflow are optional but highly recommended.

To install please download setup guide from: 
https://practicusai.github.io/helm/practicus_setup_addon.zip 
