# Installing RabbitMQ Kubernetes Operators

RabbitMQ Kubernetes operators streamline both the creation of RabbitMQ clusters and the management of resources (like exchanges and queues). There are two key operators to consider:

## 1. RabbitMQ Cluster Operator

The Cluster Operator is essential for managing RabbitMQ clusters. Follow these steps to install it:

- **Installation:**  
  Visit the <https://www.rabbitmq.com/kubernetes/operator/install-operator> and follow the detailed installation steps.

- **Post-Installation:**  
  Once the operator is installed, you can proceed to create and manage RabbitMQ clusters on your Kubernetes environment.

## 2. RabbitMQ Topology Operator

The Topology Operator is optional but a recommended addition, especially for production environments. It offers the following benefits:

- **Automated Resource Management:**  
  Easily export RabbitMQ artifacts during development and deploy them into production without manual intervention.

- **Reduced Administrative Overhead:**  
  Without the topology operator, the RabbitMQ user would need full administrative (configure) privileges in production or you’d have to manually create resources—a process prone to errors.

- **Installation:**  
  Follow the instructions provided in the <https://www.rabbitmq.com/kubernetes/operator/install-topology-operator> to set it up.
