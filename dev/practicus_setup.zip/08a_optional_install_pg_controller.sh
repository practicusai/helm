#!/bin/bash

echo ""
echo "Installing Cloud Native Postgresql controller"

kubectl apply -f \
  https://raw.githubusercontent.com/cloudnative-pg/cloudnative-pg/release-1.21/releases/cnpg-1.21.1.yaml

echo ""
echo "Waiting until pods under cnpg-system namespace are ready.."

kubectl wait --for=condition=ready --timeout=60s pod --all -n cnpg-system

echo ""
echo "Cloud Native PostgreSQL is ready!"
