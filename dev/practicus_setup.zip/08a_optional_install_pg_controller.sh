#!/bin/bash

echo ""
echo "Installing Cloud Native Postgresql controller"

kubectl apply -f \
  https://raw.githubusercontent.com/cloudnative-pg/cloudnative-pg/release-1.21/releases/cnpg-1.21.1.yaml
