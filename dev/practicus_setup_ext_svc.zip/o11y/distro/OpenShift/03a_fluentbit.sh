#!/bin/bash

DEFAULT_SVC_NAMESPACE=prt-ns-o11y

cd "$(dirname "$0")" || exit

if [[ -z "$PRT_SVC_NAMESPACE" ]]; then
    export PRT_SVC_NAMESPACE=$DEFAULT_SVC_NAMESPACE
    echo "PRT_SVC_NAMESPACE env variable is not defined, will use the default $PRT_SVC_NAMESPACE"
fi

if kubectl get namespace "$PRT_SVC_NAMESPACE" > /dev/null 2>&1; then
    echo "Namespace '$PRT_SVC_NAMESPACE' already exists"
else
    # Create the namespace if it does not exist
    kubectl create namespace "$PRT_SVC_NAMESPACE"
    echo "Namespace '$PRT_SVC_NAMESPACE' created"
fi

echo "Applying fluentbit fix for OpenShift"
kubectl apply -f 03a_fluentbit.yaml -n "$PRT_SVC_NAMESPACE"

echo "Adding Custom SCC for Fluent Bit"
oc adm policy add-scc-to-user prt-scc-fluentbit -z prt-sa-fluentbit -n "$PRT_SVC_NAMESPACE"

echo "Completed"
