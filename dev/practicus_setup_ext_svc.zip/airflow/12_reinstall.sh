#!/bin/bash

cd "$(dirname "$0")" || echo "Could not change directory to script location"

bash ./11_uninstall.sh
bash ./10_install.sh

echo "Completed reinstalling"
