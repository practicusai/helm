{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "grafana.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "grafana.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "grafana.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create the name of the service account
*/}}
{{- define "grafana.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "grafana.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "grafana.serviceAccountNameTest" -}}
{{- if .Values.serviceAccount.create }}
{{- default (print (include "grafana.fullname" .) "-test") .Values.serviceAccount.nameTest }}
{{- else }}
{{- default "default" .Values.serviceAccount.nameTest }}
{{- end }}
{{- end }}

{{/*
Allow the release namespace to be overridden for multi-namespace deployments in combined charts
*/}}
{{- define "grafana.namespace" -}}
{{- if .Values.namespaceOverride }}
{{- .Values.namespaceOverride }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "grafana.labels" -}}
helm.sh/chart: {{ include "grafana.chart" . }}
{{ include "grafana.selectorLabels" . }}
{{- if or .Chart.AppVersion .Values.image.tag }}
app.kubernetes.io/version: {{ mustRegexReplaceAllLiteral "@sha.*" .Values.image.tag "" | default .Chart.AppVersion | trunc 63 | trimSuffix "-" | quote }}
{{- end }}
{{- with .Values.extraLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "grafana.selectorLabels" -}}
app.kubernetes.io/name: {{ include "grafana.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create a fully qualified name for image-renderer resources.
We truncate at 47 chars to reserve space for the longest suffix (-image-renderer, 16 chars)
so the Service name stays within the 63-char DNS label limit.
*/}}
{{- define "grafana.imageRenderer.fullname" -}}
{{- include "grafana.fullname" . | trunc 47 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "grafana.imageRenderer.labels" -}}
helm.sh/chart: {{ include "grafana.chart" . }}
{{ include "grafana.imageRenderer.selectorLabels" . }}
{{- if or .Chart.AppVersion .Values.image.tag }}
app.kubernetes.io/version: {{ mustRegexReplaceAllLiteral "@sha.*" .Values.image.tag "" | default .Chart.AppVersion | trunc 63 | trimSuffix "-" | quote }}
{{- end }}
{{- end }}

{{/*
Selector labels ImageRenderer
*/}}
{{- define "grafana.imageRenderer.selectorLabels" -}}
app.kubernetes.io/name: {{ include "grafana.name" . }}-image-renderer
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Looks if there's an existing secret and reuse its password. If not it generates
new password and use it.
*/}}
{{- define "grafana.password" -}}
{{- $secret := (lookup "v1" "Secret" (include "grafana.namespace" .) (include "grafana.fullname" .) ) }}
{{- if $secret }}
{{- index $secret "data" "admin-password" }}
{{- else }}
{{- (randAlphaNum 40) | b64enc | quote }}
{{- end }}
{{- end }}

{{/*
Return the appropriate apiVersion for Horizontal Pod Autoscaler.
*/}}
{{- define "grafana.hpa.apiVersion" -}}
{{- if .Capabilities.APIVersions.Has "autoscaling/v2" }}
{{- print "autoscaling/v2" }}
{{- else }}
{{- print "autoscaling/v2beta2" }}
{{- end }}
{{- end }}


{{/*
Formats imagePullSecrets. Input is (dict "root" . "imagePullSecrets" .{specific imagePullSecrets})
*/}}
{{- define "grafana.imagePullSecrets" -}}
{{- $root := .root }}
{{- range (concat .root.Values.global.imagePullSecrets .imagePullSecrets) }}
{{- if eq (typeOf .) "map[string]interface {}" }}
- {{ toYaml (dict "name" (tpl .name $root)) | trim }}
{{- else }}
- name: {{ tpl . $root }}
{{- end }}
{{- end }}
{{- end }}


{{/*
 Checks whether or not the configSecret secret has to be created
 */}}
{{- define "grafana.shouldCreateConfigSecret" -}}
{{- $secretFound := false -}}
{{- range $key, $value := .Values.datasources }}
  {{- if hasKey $value "secret" }}
    {{- $secretFound = true}}
  {{- end }}
{{- end }}
{{- range $key, $value := .Values.notifiers }}
  {{- if hasKey $value "secret" }}
    {{- $secretFound = true}}
  {{- end }}
{{- end }}
{{- range $key, $value := .Values.alerting }}
  {{- if (or (hasKey $value "secret") (hasKey $value "secretFile")) }}
    {{- $secretFound = true}}
  {{- end }}
{{- end }}
{{- $secretFound}}
{{- end -}}

{{/*
    Checks whether the user is attempting to store secrets in plaintext
    in the grafana.ini configmap
*/}}
{{/* grafana.assertNoLeakedSecrets checks for sensitive keys in values */}}
{{- define "grafana.assertNoLeakedSecrets" -}}
      {{- $sensitiveKeysYaml := `
sensitiveKeys:
- path: ["database", "password"]
- path: ["smtp", "password"]
- path: ["security", "secret_key"]
- path: ["security", "admin_password"]
- path: ["auth.basic", "password"]
- path: ["auth.ldap", "bind_password"]
- path: ["auth.google", "client_secret"]
- path: ["auth.github", "client_secret"]
- path: ["auth.gitlab", "client_secret"]
- path: ["auth.generic_oauth", "client_secret"]
- path: ["auth.okta", "client_secret"]
- path: ["auth.azuread", "client_secret"]
- path: ["auth.grafana_com", "client_secret"]
- path: ["auth.grafananet", "client_secret"]
- path: ["azure", "user_identity_client_secret"]
- path: ["unified_alerting", "ha_redis_password"]
- path: ["metrics", "basic_auth_password"]
- path: ["external_image_storage.s3", "secret_key"]
- path: ["external_image_storage.webdav", "password"]
- path: ["external_image_storage.azure_blob", "account_key"]
` | fromYaml -}}
  {{- if $.Values.assertNoLeakedSecrets -}}
      {{- $grafanaIni := index .Values "grafana.ini" -}}
      {{- range $_, $secret := $sensitiveKeysYaml.sensitiveKeys -}}
        {{- $currentMap := $grafanaIni -}}
        {{- $shouldContinue := true -}}
        {{- range $index, $elem := $secret.path -}}
          {{- if and $shouldContinue (hasKey $currentMap $elem) -}}
            {{- if eq (len $secret.path) (add1 $index) -}}
              {{- if not (regexMatch "\\$(?:__(?:env|file|vault))?{[^}]+}" (index $currentMap $elem)) -}}
                {{- fail (printf "Sensitive key '%s' should not be defined explicitly in values. Use variable expansion instead. You can disable this client-side validation by changing the value of assertNoLeakedSecrets." (join "." $secret.path)) -}}
              {{- end -}}
            {{- else -}}
              {{- $currentMap = index $currentMap $elem -}}
            {{- end -}}
          {{- else -}}
              {{- $shouldContinue = false -}}
          {{- end -}}
        {{- end -}}
      {{- end -}}
  {{- end -}}
{{- end -}}

{{/*
 Sidecars health port
 */}}

{{/*
 Give health port for alerts sidecar
 */}}
{{- define "grafana.sidecar.alerts.healthPort" -}}
{{- $healthPort := 8081 -}}
{{- if hasKey .Values.sidecar.alerts "startupProbe" -}}
  {{- if hasKey .Values.sidecar.alerts.startupProbe "httpGet" -}}
    {{- if hasKey .Values.sidecar.alerts.startupProbe.httpGet "port" -}}
      {{- $healthPort = .Values.sidecar.alerts.startupProbe.httpGet.port -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $healthPort | quote -}}
{{- end -}}

{{/*
 Give health port for datasources sidecar
 */}}
{{- define "grafana.sidecar.datasources.healthPort" -}}
{{- $healthPort := 8082 -}}
{{- if hasKey .Values.sidecar.datasources "startupProbe" -}}
  {{- if hasKey .Values.sidecar.datasources.startupProbe "httpGet" -}}
    {{- if hasKey .Values.sidecar.datasources.startupProbe.httpGet "port" -}}
      {{- $healthPort = .Values.sidecar.datasources.startupProbe.httpGet.port -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $healthPort | quote -}}
{{- end -}}

{{/*
 Give health port for notifiers sidecar
 */}}
{{- define "grafana.sidecar.notifiers.healthPort" -}}
{{- $healthPort := 8083 -}}
{{- if hasKey .Values.sidecar.notifiers "startupProbe" -}}
  {{- if hasKey .Values.sidecar.notifiers.startupProbe "httpGet" -}}
    {{- if hasKey .Values.sidecar.notifiers.startupProbe.httpGet "port" -}}
      {{- $healthPort = .Values.sidecar.notifiers.startupProbe.httpGet.port -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $healthPort | quote -}}
{{- end -}}

{{/*
 Give health port for dashboards sidecar
 */}}
{{- define "grafana.sidecar.dashboards.healthPort" -}}
{{- $healthPort := 8084 -}}
{{- if hasKey .Values.sidecar.dashboards "startupProbe" -}}
  {{- if hasKey .Values.sidecar.dashboards.startupProbe "httpGet" -}}
    {{- if hasKey .Values.sidecar.dashboards.startupProbe.httpGet "port" -}}
      {{- $healthPort = .Values.sidecar.dashboards.startupProbe.httpGet.port -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $healthPort | quote -}}
{{- end -}}
