# Headlamp Helm Chart

Headlamp is an easy-to-use and extensible Kubernetes web UI that provides:
- 🚀 Modern, fast, and responsive interface
- 🔒 OIDC authentication support
- 🔌 Plugin system for extensibility
- 🎯 Real-time cluster state updates

## Prerequisites

- Kubernetes 1.21+
- Helm 3.x
- Cluster admin access for initial setup

## Quick Start

Add the Headlamp repository and install the chart:

```console
$ helm repo add headlamp https://kubernetes-sigs.github.io/headlamp/
$ helm repo update
$ helm install my-headlamp headlamp/headlamp --namespace kube-system
```

Access Headlamp:
```console
$ kubectl port-forward -n kube-system svc/my-headlamp 8080:80
```
Then open http://localhost:8080 in your browser.

## Installation

### Basic Installation
```console
$ helm install my-headlamp headlamp/headlamp --namespace kube-system
```

### Installation with OIDC
```console
$ helm install my-headlamp headlamp/headlamp \
  --namespace kube-system \
  --set config.oidc.clientID=your-client-id \
  --set config.oidc.clientSecret=your-client-secret \
  --set config.oidc.issuerURL=https://your-issuer-url
```

### Installation with Ingress
```console
$ helm install my-headlamp headlamp/headlamp \
  --namespace kube-system \
  --set ingress.enabled=true \
  --set ingress.hosts[0].host=headlamp.example.com \
  --set ingress.hosts[0].paths[0].path=/
```

### Upgrade note about image tags

If `image.tag` is set explicitly (for example in a values file or via `--set image.tag=...`), Helm upgrades will keep that value.
This means the release can show a newer chart/app version while still running an older container image.

To ensure the running image matches the chart version during upgrade, set the tag explicitly to the chart's appVersion-derived format.
```console
$ helm upgrade my-headlamp headlamp/headlamp \
  --namespace kube-system \
  --reuse-values \
  --set image.tag=v<appVersion>
```

### Installation with Cluster Inventory

> **Warning**
> Cluster Inventory support in Headlamp is alpha/experimental and disabled by
> default. The upstream Cluster Inventory API is currently `v1alpha1` and this
> integration uses the `v0.1.x` API, so fields and behavior may change.

```console
$ helm install my-headlamp headlamp/headlamp \
  --namespace kube-system \
  --values cluster-inventory-values.yaml
```

`cluster-inventory-values.yaml`:

```yaml
config:
  clusterInventory:
    enabled: true
    accessProvidersConfig:
      providers:
        - name: secretreader
          execConfig:
            apiVersion: client.authentication.k8s.io/v1
            command: /access-plugins/secretreader/bin/secretreader-plugin
            interactiveMode: Never
            provideClusterInfo: true
        - name: kubeconfig-secretreader
          execConfig:
            apiVersion: client.authentication.k8s.io/v1
            command: /access-plugins/kubeconfig-secretreader/bin/kubeconfig-secretreader-plugin
            interactiveMode: Never
            provideClusterInfo: true
    plugins:
      - name: secretreader
        image: registry.k8s.io/cluster-inventory-api/secretreader:v0.1.3@sha256:ec3090dc166aa2b42fb35d714d161c417d8b27bbc463404c8f615f5f4c610a1d
        mountPath: /access-plugins/secretreader
      - name: kubeconfig-secretreader
        image: registry.k8s.io/cluster-inventory-api/kubeconfig-secretreader:v0.1.3@sha256:b92966cc6e4ac78002a63862921022a71d54956826f6e4febcb7247495eb98c0
        mountPath: /access-plugins/kubeconfig-secretreader
```

`plugins[]` mounts Cluster Inventory access provider binaries as Kubernetes
`image` volumes; it is not for Headlamp UI plugins.

## Configuration

### Core Parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| replicaCount | int | `1` | Number of desired pods |
| image.registry | string | `"ghcr.io"` | Container image registry |
| image.repository | string | `"headlamp-k8s/headlamp"` | Container image name |
| image.tag | string | `""` | Container image tag (defaults to Chart appVersion) |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |

### Application Configuration

| Key                | Type   | Default               | Description                                                               |
|--------------------|--------|-----------------------|---------------------------------------------------------------------------|
| config.inCluster   | bool   | `true`                | Run Headlamp in-cluster                                                   |
| config.baseURL     | string | `""`                  | Base URL path for Headlamp UI                                             |
| config.sessionTTL  | int    | `86400`               | The time in seconds for the internal session to remain valid (Default: 86400/24h, Min: 1 , Max: 31536000/1yr) |
| config.unsafeUseServiceAccountToken | bool | `false` | UNSAFE: authenticate every user as the pod's service account when running in-cluster. Only safe behind an auth proxy |
| config.serviceAccountTokenPath | string | `""` | Path to the service account token file. Used only when `unsafeUseServiceAccountToken` is true |
| config.pluginsDir  | string | `"/headlamp/plugins"` | Directory to load Headlamp plugins from                                   |
| config.staticPlugins.enabled | bool | `true` | Serve the bundled static plugins shipped in the image (e.g. the Prometheus "Show Prometheus metrics" plugin). Set to false to disable them |
| config.enableHelm  | bool   | `false`               | Enable Helm operations like install, upgrade and uninstall of Helm charts |
| config.podDebugImage | string | `""`                | Default image to use when creating pod debug containers                    |
| config.nodeShellImage | string | `""`               | Default image to use when creating node shell pods                         |
| config.nodeShellNamespace | string | `""`            | Default namespace to use when creating node shell pods                      |
| config.clusterInventory.enabled | bool | `false` | Enable experimental/alpha Cluster Inventory discovery |
| config.clusterInventory.accessProvidersConfig | object | `{}` | Experimental/alpha Cluster Inventory access providers config. Required when Cluster Inventory is enabled |
| config.clusterInventory.plugins | list | `[]` | Kubernetes image volumes that provide experimental/alpha Cluster Inventory access provider binaries |
| config.clusterInventory.labelSelector | string | `"!headlamp.dev/ignore"` | Kubernetes label selector used to filter experimental/alpha ClusterProfile resources |
| config.clusterInventory.rootReconcileInterval | string | `""` | Override the experimental/alpha Cluster Inventory root reconcile interval. Empty uses the Headlamp default |
| config.clusterInventory.noCRDCacheTTL | string | `""` | Override the experimental/alpha Cluster Inventory no-CRD cache TTL. Empty uses the Headlamp default |
| config.extraArgs   | array  | `[]`                  | Additional arguments for Headlamp server                                  |
| config.tlsCertPath | string | `""`                  | Certificate for serving TLS                                               |
| config.tlsKeyPath  | string | `""`                  | Key for serving TLS                                                       |

When `config.unsafeUseServiceAccountToken` is enabled, the token file must be
mounted and readable in the Headlamp container. The default path is provided by
`automountServiceAccountToken`; custom paths require a matching projected
volume or volume mount.

### OIDC Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| config.oidc.clientID | string | `""` | OIDC client ID |
| config.oidc.clientSecret | string | `""` | OIDC client secret |
| config.oidc.issuerURL | string | `""` | OIDC issuer URL |
| config.oidc.scopes | string | `""` | OIDC scopes to be used |
| config.oidc.usePKCE | bool | `false` | Use PKCE (Proof Key for Code Exchange) for enhanced security in OIDC flow |
| config.oidc.useCookie | bool | `false` | Enable using OIDC cookie for authentication outside of cluster |
| config.oidc.secret.create | bool | `true` | Create OIDC secret using provided values |
| config.oidc.secret.name | string | `"oidc"` | Name of the OIDC secret |
| config.oidc.externalSecret.enabled | bool | `false` | Enable using external secret for OIDC |
| config.oidc.externalSecret.name | string | `""` | Name of external OIDC secret |
| config.oidc.meUserInfoURL | string | `""` | URL to fetch additional user info for the /me endpoint. Useful for providers like oauth2-proxy. |

There are three ways to configure OIDC:

1. Using direct configuration:
```yaml
config:
  oidc:
    clientID: "your-client-id"
    clientSecret: "your-client-secret"
    issuerURL: "https://your-issuer"
    scopes: "openid profile email"
    meUserInfoURL: "https://headlamp.example.com/oauth2/userinfo"
```

2. Using automatic secret creation:
```yaml
config:
  oidc:
    secret:
      create: true
      name: oidc
```

3. Using external secret:
```yaml
config:
  oidc:
    secret:
      create: false
    externalSecret:
      enabled: true
      name: your-oidc-secret
```

### Cluster Inventory Configuration

> **Warning**
> Cluster Inventory support in Headlamp is alpha/experimental and disabled by
> default. The upstream Cluster Inventory API is currently `v1alpha1` and this
> integration uses the `v0.1.x` API, so fields and behavior may change.

When `config.clusterInventory.enabled` is true, the chart creates a provider
ConfigMap, makes it available read-only at `/etc/cluster-inventory/config.json`,
and adds the Headlamp Cluster Inventory flags automatically.

```yaml
config:
  clusterInventory:
    enabled: true
    accessProvidersConfig:
      providers:
        - name: secretreader
          execConfig:
            apiVersion: client.authentication.k8s.io/v1
            command: /access-plugins/secretreader/bin/secretreader-plugin
            interactiveMode: Never
            provideClusterInfo: true
        - name: kubeconfig-secretreader
          execConfig:
            apiVersion: client.authentication.k8s.io/v1
            command: /access-plugins/kubeconfig-secretreader/bin/kubeconfig-secretreader-plugin
            interactiveMode: Never
            provideClusterInfo: true
    plugins:
      - name: secretreader
        image: registry.k8s.io/cluster-inventory-api/secretreader:v0.1.3@sha256:ec3090dc166aa2b42fb35d714d161c417d8b27bbc463404c8f615f5f4c610a1d
        mountPath: /access-plugins/secretreader
      - name: kubeconfig-secretreader
        image: registry.k8s.io/cluster-inventory-api/kubeconfig-secretreader:v0.1.3@sha256:b92966cc6e4ac78002a63862921022a71d54956826f6e4febcb7247495eb98c0
        mountPath: /access-plugins/kubeconfig-secretreader
```

`plugins[]` is for Cluster Inventory access provider binaries, not Headlamp UI
plugins. Each entry renders as a Kubernetes `image` volume and is mounted
read-only into the Headlamp container. If an access provider `execConfig.command`
is configured, the command must be under one of the absolute
`plugins[].mountPath` values.

### Deployment Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| replicaCount | int | `1` | Number of desired pods |
| image.registry | string | `"ghcr.io"` | Container image registry |
| image.repository | string | `"headlamp-k8s/headlamp"` | Container image name |
| image.tag | string | `""` | Container image tag (defaults to Chart appVersion) |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| imagePullSecrets | list | `[]` | Image pull secrets references |
| nameOverride | string | `""` | Override the name of the chart |
| fullnameOverride | string | `""` | Override the full name of the chart |
| namespaceOverride | string | `""` | Override the deployment namespace; defaults to .Release.Namespace |
| initContainers | list | `[]` | Init containers to run before main container |

### Security Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| automountServiceAccountToken | bool | `true` | Mount Service Account token in pod |
| serviceAccount.create | bool | `true` | Create service account |
| serviceAccount.name | string | `""` | Service account name |
| serviceAccount.annotations | object | `{}` | Service account annotations |
| clusterRoleBinding.create | bool | `true` | Create cluster role binding |
| clusterRoleBinding.clusterRoleName | string | `"cluster-admin"` | Kubernetes ClusterRole name |
| clusterRoleBinding.annotations | object | `{}` | Cluster role binding annotations |
| hostUsers | bool | `true` | Run in host uid namespace |
| podSecurityContext | object | `{}` | Pod security context (e.g., fsGroup: 2000) |
| securityContext.runAsNonRoot | bool | `true` | Run container as non-root |
| securityContext.privileged | bool | `false` | Run container in privileged mode |
| securityContext.runAsUser | int | `100` | User ID to run container |
| securityContext.runAsGroup | int | `101` | Group ID to run container |
| securityContext.capabilities | object | `{}` | Container capabilities (e.g., drop: [ALL]) |
| securityContext.readOnlyRootFilesystem | bool | `false` | Mount root filesystem as read-only |

NOTE: for `hostUsers=false` user namespaces must be supported. See: https://kubernetes.io/docs/concepts/workloads/pods/user-namespaces/

### Storage Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| persistentVolumeClaim.enabled | bool | `false` | Enable PVC |
| persistentVolumeClaim.annotations | object | `{}` | PVC annotations |
| persistentVolumeClaim.size | string | `""` | PVC size (required if enabled) |
| persistentVolumeClaim.storageClassName | string | `""` | Storage class name |
| persistentVolumeClaim.accessModes | list | `[]` | PVC access modes |
| persistentVolumeClaim.selector | object | `{}` | PVC selector |
| persistentVolumeClaim.volumeMode | string | `""` | PVC volume mode |
| volumeMounts | list | `[]` | Container volume mounts |
| volumes | list | `[]` | Pod volumes |

### Read-only root filesystem

When `securityContext.readOnlyRootFilesystem: true` is set, the application needs a writable `/tmp` directory. The chart handles this automatically:

- An `emptyDir` volume named `headlamp-tmp` is created and mounted at `/tmp` in the main container.
- If `pluginsManager` is enabled and its effective security context (own or inherited) also sets `readOnlyRootFilesystem: true`, a separate `emptyDir` volume named `headlamp-plugins-tmp` is created and mounted at `/tmp` in the plugin manager container.

**Overriding the automatic `/tmp` volume:**

You can customise this behaviour without losing the automatic mount:

```yaml
# Provide your own headlamp-tmp volume (e.g. to set a size limit).
# The chart will skip creating the volume but will still add the /tmp mount.
volumes:
  - name: headlamp-tmp
    emptyDir:
      sizeLimit: 256Mi
```

To take full control of `/tmp` (and suppress both the automatic mount and volume entirely), add your own `volumeMount` with `mountPath: /tmp`:

```yaml
volumeMounts:
  - name: my-tmp
    mountPath: /tmp
volumes:
  - name: my-tmp
    emptyDir: {}
```

### Network Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| service.type | string | `"ClusterIP"` | Kubernetes service type |
| service.port | int | `80` | Kubernetes service port |
| service.extraServicePorts | list | `[]` | Additional ports to expose on the Service in addition to the default http port |
| ingress.enabled | bool | `false` | Enable ingress |
| ingress.ingressClassName | string | `""` | Ingress class name |
| ingress.annotations | object | `{}` | Ingress annotations (e.g., kubernetes.io/tls-acme: "true") |
| ingress.labels | object | `{}` | Additional labels for the Ingress resource |
| ingress.hosts | list | `[]` | Ingress hosts configuration |
| ingress.tls | list | `[]` | Ingress TLS configuration |

Example ingress configuration:
```yaml
ingress:
  enabled: true
  annotations:
    kubernetes.io/tls-acme: "true"
  labels:
    app.kubernetes.io/part-of: traefik
    environment: prod
  hosts:
    - host: headlamp.example.com
      paths:
        - path: /
          type: ImplementationSpecific
  tls:
    - secretName: headlamp-tls
      hosts:
        - headlamp.example.com
```

Each path under `ingress.hosts[].paths[]` may optionally specify
`backend.service.{name,port}` to override the default Headlamp Service /
`service.port`. This is typically combined with `service.extraServicePorts` to
route different paths to different ports of the same Service:

```yaml
service:
  extraServicePorts:
    - name: extra
      port: 9090
      targetPort: extra

ingress:
  enabled: true
  hosts:
    - host: headlamp.example.com
      paths:
        - path: /
          type: Prefix
        - path: /extra
          type: Prefix
          backend:
            service:
              # name is optional; defaults to the Headlamp Service.
              # When set, it is rendered with `tpl` so values like
              # "{{ .Release.Name }}-other" are supported.
              port:
                name: extra        # or: number: 9090
```

The same approach works for the Gateway API: define additional ports under
`service.extraServicePorts` and reference them from `httpRoute.rules[].backendRefs[].port`.


### HTTPRoute Configuration (Gateway API)

For users who prefer Gateway API over classic Ingress resources, Headlamp supports HTTPRoute configuration.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| httpRoute.enabled | bool | `false` | Enable HTTPRoute resource for Gateway API |
| httpRoute.annotations | object | `{}` | Annotations for HTTPRoute resource |
| httpRoute.labels | object | `{}` | Additional labels for HTTPRoute resource |
| httpRoute.parentRefs | list | `[]` | Parent gateway references (REQUIRED when enabled) |
| httpRoute.hostnames | list | `[]` | Hostnames for the HTTPRoute |
| httpRoute.rules | list | `[]` | Custom routing rules (optional, defaults to path prefix /) |

Example HTTPRoute configuration:
```yaml
httpRoute:
  enabled: true
  annotations:
    gateway.example.com/custom-annotation: "value"
  labels:
    app.kubernetes.io/component: ingress
  parentRefs:
    - name: my-gateway
      namespace: gateway-namespace
  hostnames:
    - headlamp.example.com
  # Optional custom rules (defaults to path prefix / if not specified)
  rules:
    - matches:
        - path:
            type: PathPrefix
            value: /headlamp
      backendRefs:
        - name: my-headlamp
          port: 80
```

### Probe Configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| probes.scheme | string | `"HTTP"` | Scheme for liveness/readiness probes (HTTP or HTTPS). Set to HTTPS when TLS is enabled at the backend. |
| probes.livenessProbe.initialDelaySeconds | int | `0` | Initial delay before liveness probe starts |
| probes.livenessProbe.periodSeconds | int | `10` | Period between liveness checks |
| probes.livenessProbe.timeoutSeconds | int | `1` | Timeout for liveness probe |
| probes.livenessProbe.successThreshold | int | `1` | Must be 1 for liveness probes (Kubernetes requirement) |
| probes.livenessProbe.failureThreshold | int | `3` | Minimum consecutive failures |
| probes.readinessProbe.initialDelaySeconds | int | `0` | Initial delay before readiness probe starts |
| probes.readinessProbe.periodSeconds | int | `10` | Period between readiness checks |
| probes.readinessProbe.timeoutSeconds | int | `1` | Timeout for readiness probe |
| probes.readinessProbe.successThreshold | int | `1` | Minimum consecutive successes |
| probes.readinessProbe.failureThreshold | int | `3` | Minimum consecutive failures |

When using TLS termination at the backend server, you must set `probes.scheme` to `HTTPS`:

```yaml
config:
  tlsCertPath: "/headlamp-cert/tls.crt"
  tlsKeyPath: "/headlamp-cert/tls.key"

probes:
  scheme: HTTPS  # Required when TLS is enabled at backend

volumes:
  - name: headlamp-cert
    secret:
      secretName: headlamp-tls

volumeMounts:
  - name: headlamp-cert
    mountPath: /headlamp-cert
```

### Resource Management

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| resources | object | `{}` | Container resource requests/limits |
| nodeSelector | object | `{}` | Node labels for pod assignment |
| tolerations | list | `[]` | Pod tolerations |
| affinity | object | `{}` | Pod affinity settings |
| hostAliases | list | `[]` | Optional list of host/IP mappings injected into the pod's /etc/hosts. Useful when an external host (e.g. an OIDC issuer behind cluster ingress) is not resolvable via cluster DNS. |
| topologySpreadConstraints | list | `[]` | Topology spread constraints for pod assignment |
| podAnnotations | object | `{}` | Pod annotations |
| podLabels | object | `{}` | Pod labels |
| env | list | `[]` | Additional environment variables |

Example resource configuration:
```yaml
resources:
  limits:
    cpu: 100m
    memory: 128Mi
  requests:
    cpu: 100m
    memory: 128Mi
```

Example environment variables:
```yaml
env:
  - name: KUBERNETES_SERVICE_HOST
    value: "localhost"
  - name: KUBERNETES_SERVICE_PORT
    value: "6443"
```

Example topology spread constraints:
```yaml
# Spread pods across availability zones with best-effort scheduling
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: ScheduleAnyway  # Prefer spreading but allow scheduling even if it violates the constraint
    matchLabelKeys:
      - pod-template-hash
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: DoNotSchedule  # Hard requirement - don't schedule if it violates the constraint
    matchLabelKeys:
      - pod-template-hash
```

The `labelSelector` is automatically populated with the pod's selector labels if not specified. You can also provide a custom `labelSelector`:
```yaml
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: ScheduleAnyway
    labelSelector:
      matchLabels:
        app.kubernetes.io/name: headlamp
        custom-label: value
```

### Pod Disruption Budget (PDB)

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| podDisruptionBudget.enabled | bool | `false` | Create a PodDisruptionBudget resource |
| podDisruptionBudget.minAvailable | integer \| string \| null | `0` | Minimum pods that must be available. Rendered only when set to a positive integer or a percentage string (e.g. `"1"` or `"50%"`). Schema default is 0, but the chart skips rendering `0`. |
| podDisruptionBudget.maxUnavailable | integer \| string \| null | `null` | Maximum pods allowed to be unavailable. Accepts integer >= 0 or percentage string. Mutually exclusive with `minAvailable`; the template renders this field when set. |
| podDisruptionBudget.unhealthyPodEvictionPolicy | string \| null | `null` | Eviction policy: `"IfHealthyBudget"` or `"AlwaysAllow"`. Emitted only on clusters running Kubernetes >= 1.27 and when explicitly set in values. |

Note: Ensure `minAvailable` and `maxUnavailable` are not both set (use `null` to disable one). To include `minAvailable` in the rendered PDB, set a positive integer or percentage; the template omits a `0` value.

Example, Require at least 1 pod available (ensure maxUnavailable is disabled):
```yaml
podDisruptionBudget:
  enabled: true
  minAvailable: 1
  maxUnavailable: null
```

Example, Allow up to 50% of pods to be unavailable:
```yaml
podDisruptionBudget:
  enabled: true
  maxUnavailable: "50%"
  minAvailable: null
```

Example, Set unhealthyPodEvictionPolicy (requires Kubernetes >= 1.27):
```yaml
podDisruptionBudget:
  enabled: true
  maxUnavailable: 1
  minAvailable: null
  unhealthyPodEvictionPolicy: "IfHealthyBudget"
```

Ensure your replicaCount and maintenance procedures respect the configured PDB to avoid blocking intended operations.

### pluginsManager Configuration

| Key             | Type    | Default           | Description                                                                               |
|-----------------|---------|-------------------|-------------------------------------------------------------------------------------------|
| enabled         | boolean | `false`           | Enable plugin manager                                                                     |
| configFile      | string  | `plugin.yml`      | Plugin configuration file name                                                            |
| configContent   | string  | `""`              | Plugin configuration content in YAML format. This is required if plugins.enabled is true. |
| baseImage       | string  | `node:lts-alpine` | Base node image to use                                                                    |
| version         | string  | `latest`          | Headlamp plugin package version to install                                                |
| env             | list    | `[]`              | Plugin manager env variable configuration                                                 |
| resources       | object  | `{}`              | Plugin manager resource requests/limits                                                   |
| volumeMounts    | list    | `[]`              | Plugin manager volume mounts                                                              |
| securityContext | object  | `{}`              | Plugin manager security context. If omitted, inherits the global `securityContext`.       |

Example resource configuration:

```yaml
pluginsManager:
  enabled: true
  baseImage: node:lts-alpine
  version: latest
  env:
    - name: HTTPS_PROXY
      value: "proxy.example.com:8080"
  resources:
    requests:
      cpu: "500m"
      memory: "2048Mi"
    limits:
      cpu: "1"
      memory: "4Gi"
```
## Contributing

We welcome contributions to the Headlamp Helm chart! To contribute:

1. Fork the repository and create your branch from `main`.
2. Make your changes and test them thoroughly.
3. Run Helm chart template tests to ensure your changes don't break existing functionality:

   ```console
   $ make helm-template-test
   ```
   This command executes the script at `charts/headlamp/tests/test.sh` to validate Helm chart templates against expected templates.

4. If you've made changes that intentionally affect the rendered templates (like version updates or new features):

   ```console
   $ make helm-update-template-version
   ```
   This updates the expected templates with the current versions from Chart.yaml and only shows files where versions changed.

5. Review the updated templates carefully to ensure they contain only your intended changes.

6. Submit a pull request with a clear description of your changes.


For more details, refer to our [contributing guidelines](https://github.com/kubernetes-sigs/headlamp/blob/main/CONTRIBUTING.md).

## Links

- [GitHub Repository](https://github.com/kubernetes-sigs/headlamp)
- [Documentation](https://headlamp.dev/)
- [Maintainers](https://github.com/kubernetes-sigs/headlamp/blob/main/OWNERS_ALIASES)
