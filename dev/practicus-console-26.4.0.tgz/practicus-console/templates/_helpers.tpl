{{- define "generateHosts" }}
    {{- range .Values.main.hosts }}
- "{{ . }}"
        {{- if not (hasPrefix "*" .) }}
- "*.{{ . }}"
        {{- end }}
    {{- end }}
{{- end }}

{{- define "generateGatewayHosts" }}
    {{- if .Values.istio.gatewayHosts }}
        {{- range .Values.istio.gatewayHosts }}
- "{{ . }}"
            {{- if and (not (hasPrefix "*" .)) (ne . "*") }}
- "*.{{ . }}"
            {{- end }}
        {{- end }}
    {{- else }}
        {{- range .Values.main.hosts }}
- "{{ . }}"
            {{- if not (hasPrefix "*" .) }}
- "*.{{ . }}"
            {{- end }}
        {{- end }}
    {{- end }}
{{- end }}