** CAREFUL services/values.yaml is overwritten **

Services helm is almost a replica of console helm installation, except it runs different binaries inside the same console container, runs different virtual services etc. 

services/values.yaml is also a copy of console/values.yaml

If you need separate values.yaml values, update deployment scripts accordingly.
