# Fluent Bit Changes
Fluent bit requires low level access and OpenShift is very sensitive.

Please view the below to understand why we need this change and other details.
https://github.com/chronosphereio/calyptia-openshift-fluent-bit-examples/tree/main/cluster-log-access

Other reading material:
https://www.redhat.com/en/blog/openshift-logging-forwarding-logs-to-external-loki

Alternative SCC from Fluent 
https://raw.githubusercontent.com/fluent/fluent-bit-kubernetes-logging/master/fluent-bit-openshift-security-context-constraints.yaml

# Alternative log forwarder 

- Instead of using Fluent bit forwarder to Loki, you can also use OpenShift's logging operator
- Important Note: This method is less mature compared to native Fluentbit and might require some extra tweaking.

# Loki and Grafana SCC Changes

- We will be creating Service account and granting anyuid scc for Loki and privileged for Grafana
- Note: It can be possible to tweak Grafana helm chart to avoid grant privileged scc
  - Disabling testFramework in grafana helm chart can remove CHOWN requirement
  - Granting anyuid scc might allow running as user 472
  - The above steps have not gone through detailed testing.

# Disabling Prometheus and Metrics Server

We will be disabling Prometheus and Metrics Server using values.yal later sice these are shipped with OpenShift.
