# Practicus AI Metrics on OpenShift

- Practicus AI Console > ML Model Hosting > Create Observability Setting
- Practicus AI Console > ML Model Hosting > Model Prefixes > Assign observability setting to a model prefix 
- Note: You can also apply an observability setting to a model or  model version
- Crete model deployment with observability enabled  
- Deploy a model and make predictions
- OpenShift Console > Observe > Targets : search for "prt-ns", you should see the monitor e.g. prt-svc-monitor-prt-ns "Status" Up
- OpenShift Console > Observe > Metrics : Type "practicus" multiple metrics should appear, e.g. practicus_model_percentiles

# Troubleshooting

- Is service monitor and model deployment in the same namespace? Unlike other K8s distros OCP doesn't seem to allow cross namespace monitoring  
- Are metrics endpoint accessible: Inside "openshift-monitoring" namespace, open a terminal to any prometheus pod 
- Replace service name and namespace below and see if 
  1) /metrics/ endpoint is accessible from prometheus
  2) If metrics are properly published. .e.g 

```shell
curl http://<service name>.<namespace>.svc.cluster.local:8000/metrics/
# e.g. for modelhost deployment name depl1 and for prt-ns 
curl http://prt-svc-modelhost-depl1.prt-ns.svc.cluster.local:8000/metrics/
```

- If /metrics/ endpoint is not working;
- Are metrics published: Open any modelhost pod logs, you should see "practicus.modelhost.observer" logs

```json
{"time": "2024-04-29T21:03:22.180338", "level": "DEBUG", "name": "practicus.modelhost.observer", "message": "Publishing 'prediction' percentiles: | percentile: 50% | value: 524.2889 | model: models/ice-cream-revenue(id: 1)/v1/"}
```
- If logs are missing on modelhost pod observability might not be enabled or a model request with observability request might be missing.
- Verify observability setting is applied to the model prefix.  
