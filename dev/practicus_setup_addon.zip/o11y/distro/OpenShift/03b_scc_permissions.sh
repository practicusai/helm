#!/bin/bash

DEFAULT_SVC_NAMESPACE=prt-ns-o11y

if [ -z "$PRT_SVC_NAMESPACE" ]; then
    export PRT_SVC_NAMESPACE=$DEFAULT_SVC_NAMESPACE
    echo "PRT_SVC_NAMESPACE env variable is not defined, will use the default $PRT_SVC_NAMESPACE"
fi

echo "Creating SA for Loki"
oc create serviceaccount prt-sa-loki -n "$PRT_SVC_NAMESPACE"
echo "Adding SCC for Loki"
oc adm policy add-scc-to-user anyuid -z prt-sa-loki -n "$PRT_SVC_NAMESPACE"

echo "Creating SA for Grafana"
oc create serviceaccount prt-sa-grafana -n "$PRT_SVC_NAMESPACE"
echo "Adding SCC for Grafana"
oc adm policy add-scc-to-user privileged -z prt-sa-grafana -n "$PRT_SVC_NAMESPACE"

echo "Completed"