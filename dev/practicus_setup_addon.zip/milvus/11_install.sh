#!/bin/bash

SERVICE_KEY=milvus
DEFAULT_SVC_NAME=practicus-milvus
DEFAULT_SVC_NAMESPACE=prt-ns-milvus

cd "$(dirname "$0")" || exit

if [ -z "$PRT_SVC_NAME" ]; then
    export PRT_SVC_NAME=$DEFAULT_SVC_NAME
    echo "PRT_SVC_NAME env variable is not defined, will use the default $PRT_SVC_NAME"
fi

if [ -z "$PRT_SVC_NAMESPACE" ]; then
    export PRT_SVC_NAMESPACE=$DEFAULT_SVC_NAMESPACE
    echo "PRT_SVC_NAMESPACE env variable is not defined, will use the default $PRT_SVC_NAMESPACE"
fi

if kubectl get namespace "$PRT_SVC_NAMESPACE" > /dev/null 2>&1; then
    echo "Namespace '$PRT_SVC_NAMESPACE' already exists"
else
    # Create the namespace if it does not exist
    kubectl create namespace "$PRT_SVC_NAMESPACE"
    echo "Namespace '$PRT_SVC_NAMESPACE' created"
fi

echo ""
echo "Installing $PRT_SVC_NAME"
helm install "$PRT_SVC_NAME" "practicus-$SERVICE_KEY" \
  --namespace "$PRT_SVC_NAMESPACE" \
  --values "values.yaml"

echo "Completed $PRT_SVC_NAME installation"
