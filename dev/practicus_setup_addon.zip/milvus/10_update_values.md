# Configuring your service using values.yaml

- A values.yaml file must be downloaded to the service directory after your you 01_prepare.sh script
- Please go through all the settings and update as needed.
- Practicus AI and parent chart values.yaml files also acts as the setup documentation of the service. After you review Practicus AI values.yaml files, you can also go through parent chart .yaml files to fine tune your configuration.
- Tip: You can delete values.yaml sections that are not used, so future helm updates can automatically update those parts.

## Changing default service name and namespace

- If you would like to change the default service name and namespace you can set PRT_SVC_NAME and PRT_SVC_NAMESPACE environment variables before running 10_install.sh script
- E.g. :

```shell
export PRT_SVC_NAME=my-custom-service-name
export PRT_SVC_NAMESPACE=my-custom-service-namespace
```
