#!/bin/bash

SERVICE_KEY=milvus

cd "$(dirname "$0")" || exit

echo ""
echo "Adding practicusai helm repo"
helm repo add practicusai https://practicusai.github.io/helm || echo " - Practicus AI helm repo already added"

echo "Updating all helm repos on your computer"
helm repo update

echo "Granting run permissions to installation scripts."
chmod +x 11_install.sh
chmod +x 12_upgrade.sh
chmod +x 13_uninstall.sh
chmod +x 14_reinstall.sh

echo "Copying default values.yaml"
rm -r "./practicus-$SERVICE_KEY" || echo " - No current helm files to delete, all good."
helm pull "practicusai/practicus-$SERVICE_KEY" --untar
cp "./practicus-$SERVICE_KEY/values.yaml" ./

echo ""
echo "Completed preparing"

echo ""
echo "Important! Please verify current kubectl context before installing."
current_kubectl_context=$(kubectl config current-context)
echo "Current kubernetes context: $current_kubectl_context"

echo ""