# Getting Started

Before you begin, please make sure you review the below list.

## Common Pre-requisites

- A Kubernetes cluster
- kubectl installed, and using the desired context (your target kubernetes cluster)
- helm installed

## Other Pre-requisites

- S3 with correct policy. Note: Milvus writes to child folders in the bucket (e.g. prt-milvus). See sample below:

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": "s3:*",
            "Resource": [
                "arn:aws:s3:::prt-milvus",
                "arn:aws:s3:::prt-milvus/*"
            ]
        }
    ]
}

```
