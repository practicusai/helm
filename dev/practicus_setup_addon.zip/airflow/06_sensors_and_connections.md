# Sensors, Connections, and the Triggerer

This service is a stock `apache/airflow` deployment (see `Dockerfile-airflow-base`) plus the
Practicus AI auth/logging plugin. Sensors and Connections are plain Airflow features, not something
Practicus AI generates or restricts - `prt.workflows.generate_files()` only produces the
`PythonOperator` task boilerplate covered in the SDK's Airflow sample notebook. This page covers the
parts specific to running sensors on top of a Practicus AI deployment.

## Where sensors run

A sensor (e.g. `SqlSensor`, `HttpSensor`, `FileSensor`) executes its `poke()`/`execute()` logic
**inside the Airflow scheduler pod**, using whatever Python packages are installed in the Airflow
container image. This is different from a normal Practicus AI task, which runs remotely on a
Practicus AI Worker via `AirflowHelper.run_airflow_task`. Practical implications:

- Any DB driver/provider a sensor needs must be installed in the **Airflow image**, not on a Worker.
- The Airflow scheduler pod's network must be able to reach the target system directly (DB port,
  HTTP endpoint, etc.) - check NetworkPolicies if the sensor times out without any error.

Write sensors by hand in the DAG file (the file produced by `generate_files()`, or any DAG pushed to
the git-sync repo) alongside your generated Practicus AI tasks. They can depend on each other in the
same DAG.

## Provider coverage

The base image (`apache/airflow:3.2.2-python3.12`) already bundles several first-party providers, so
`SqlSensor` works out of the box for **Postgres, MySQL, and Snowflake** without any changes. If your
database isn't covered (e.g. MS SQL Server, Oracle, Trino, Teradata, Databricks, or any other
provider on PyPI), you can add it yourself by building a custom Airflow image on top of ours:

```dockerfile
FROM ghcr.io/practicusai/practicus-airflow:26.4.3

USER 50000

# Pin the version and check it against the Airflow "constraints" file for your
# Airflow/Python version before installing, to avoid dependency conflicts.
RUN pip install --no-cache-dir apache-airflow-providers-microsoft-mssql==<version>
```

```shell
docker buildx build -t my-registry.my-company.com/practicus-airflow-custom:26.4.3 --push .
```

Then point `values.yaml` at it:

```yaml
airflow:
  images:
    airflow:
      repository: my-registry.my-company.com/practicus-airflow-custom
      tag: "26.4.3"
```

and roll it out with `12_upgrade.sh` (or `helm upgrade` directly).

## Defining Connections

Sensors resolve their target through an Airflow **Connection** (`conn_id`). Two supported ways to
provide one:

**1) Environment variable secret (recommended)** - see the commented `extraSecrets` /
`extraEnvFrom` example in `values.yaml` near the git-sync secret. Provisioned automatically on every
pod, doesn't require anyone to have Airflow UI access, and doesn't depend on the fernet key.

**2) Airflow UI (Admin > Connections)** - requires the user's Practicus AI OAuth `roles` claim to
map to Airflow's `Admin` or `Op` role (see `practicus_airflow_plugin.security_manager`); everyone
else defaults to `Public` and won't see this menu. Connections saved this way are encrypted with
Airflow's fernet key, so make sure `airflow.fernetKeySecretName` is set to a stable secret (see the
comment above `fernetKey` in `values.yaml`) before anyone starts saving Connections - reinstalling
with an auto-generated fernet key makes previously saved Connections undecryptable.

## Deferrable sensors and the triggerer

`airflow.triggerer.enabled` is `false` by default in `values.yaml`, only because normal Practicus AI
tasks offload their processing to remote Workers and don't need it - it is not a limitation on what
Airflow itself supports.

- Default poke-mode sensors and `mode="reschedule"` sensors work fine with the triggerer disabled.
- If you set `deferrable=True` on an operator/sensor, or use an `*Async` sensor variant (e.g.
  `TimeSensorAsync`), that task moves to a `deferred` state and **waits indefinitely** unless a
  triggerer is running. Set `airflow.triggerer.enabled: true` in `values.yaml` if you need this.

For long-running sensors, prefer `mode="reschedule"` over the default poke mode either way - it
frees the scheduler slot between polls instead of holding it for the sensor's entire wait time.

## Example

```python
from airflow.providers.common.sql.sensors.sql import SqlSensor
from airflow.operators.python import PythonOperator
import practicuscore as prt

wait_for_data = SqlSensor(
    task_id="wait_for_data",
    conn_id="my_db",
    sql="SELECT 1 FROM my_table WHERE status = 'ready' LIMIT 1;",
    mode="reschedule",
    poke_interval=300,
    timeout=60 * 60 * 6,
)

process_data = PythonOperator(
    task_id="process_data",
    python_callable=prt.workflows.run_airflow_task,
)

wait_for_data >> process_data
```

`wait_for_data` runs in the Airflow scheduler pod against the `my_db` Connection; once it succeeds,
`process_data` runs as a normal Practicus AI task on a Practicus AI Worker.
