#!/bin/bash

DEFAULT_SVC_NAMESPACE=prt-ns-airflow

if [ -z "$PRT_SVC_NAMESPACE" ]; then
    export PRT_SVC_NAMESPACE=$DEFAULT_SVC_NAMESPACE
    echo "PRT_SVC_NAMESPACE env variable is not defined, will use the default $PRT_SVC_NAMESPACE"
fi

echo "Creating SA for Airflow"
oc create serviceaccount prt-sa-airflow -n "$PRT_SVC_NAMESPACE"
echo "Adding SCC for Airflow"
oc adm policy add-scc-to-user anyuid -z prt-sa-airflow -n "$PRT_SVC_NAMESPACE"

echo "Completed"