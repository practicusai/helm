# Setting up Enterprise Single Sign-On

- Airflow Practicus AI service require Enterprise SSO to operate.

## Step 1) Create an SSO App
- Visit Practicus AI admin console > Ent. Single Sign-On > Applications > Add application
- Note "Client id"
- Enter the below in "Redirect uris" section by replacing service DNS entry E.g. : 
- https://airflow-practicus.company.com/oauth-authorized/practicus_ai
- Select "Confidential" for "Client type" section.
- Select "Authorization code" for "Authorization grant type"
- Carefully note "Client secret". *Secret will not be displayed again* 
- Enter a meaningful SSO app name. E.g: "airflow-primary-sso" This name is for internal use only. 
- Select "skip authorization". 
  - Note: We can skip authorization so the users are not asked to "accept" for the service to authenticate with Practicus AI. Since you own all the services, explicit user confirmation is not needed. 
- Select "RSA with SHA-2 256" option for "Algorithm"
- Save the SSO app.

## Step 2) Create the service
- Visit Practicus AI admin console > Services > Add Service
- Select a service key E.g. "airflow-primary". 
  - This key can be end user facing via SDK use.
- Select an end-user friendly name for the service E.g. "Airflow Primary". 
  - Although service name is mostly for GUIs, SDK calls can also be made using names.
- Select Service Type
- Enter primary url E.g. :
- https://airflow-practicus.company.com/
- Select the SSO app you created in the above step.
- You do not need to setup additional db, object storage etc settings since these wil lbe set in helm chart
- Grant access to the service using groups (recommended) or individual users. 
- Important! Carefully assign editor and admin permissions since these are directly integrated in Airflow.
- Click Save
