# Airflow REST API access using Practicus AI add-on tokens

In addition to browser SSO login, developers can call the Airflow REST API (`/api/v2/...`)
programmatically without ever creating a separate Airflow username/password. This is done by
exchanging a short-lived Practicus AI add-on session token for a standard Airflow API JWT.

## How it works

1. The developer already has a Practicus AI login (console session or SDK login).
2. Using the Practicus AI SDK, they request a session token scoped to this Airflow service
   (the "Service key" you chose in `03_setup_sso.md` step 2, matches `PRT_ADDON_KEY` below):
   ```python
   import practicuscore as prt
   addon_token = prt.addons.get_session_token(key="airflow-primary")
   ```
3. The token is exchanged for an Airflow API JWT via the standard Airflow token endpoint:
   ```python
   import requests
   resp = requests.post(
       "https://airflow-practicus.my-company.com/auth/token",
       json={"practicus_token": addon_token},
   )
   airflow_token = resp.json()["access_token"]
   ```
   (Equivalently, the add-on token can be sent as `Authorization: Bearer <addon_token>` instead of
   in the request body.)
4. The returned `access_token` is a normal Airflow JWT (`[api_auth] jwt_expiration_time`, 24h by
   default) and can be used against `/api/v2/*` exactly like any other Airflow API token:
   ```python
   requests.get(
       "https://airflow-practicus.my-company.com/api/v2/dags",
       headers={"Authorization": f"Bearer {airflow_token}"},
   )
   ```

This is implemented by `practicus_airflow_plugin.auth_manager.PracticusAirflowAuthManager`, which
overrides Airflow's `FabAuthManager.create_token()`. Username/password requests to `/auth/token`
still work unchanged (useful for DB-only service accounts).

**Important:** The developer's Practicus AI user must have already logged into the Airflow UI once
via SSO (see `03_setup_sso.md`) so a corresponding Airflow user exists. If not, `/auth/token` returns
`401 Unauthorized` with a message asking them to log in via SSO first.

## Required configuration

In `values.yaml`, in addition to the `PRT_OAUTH_*` settings from `03_setup_sso.md`, set:

- `PRT_JWT_ISSUER` / `PRT_JWT_PUBLIC_KEY`: must match the JWT issuer/public key used by the
  Practicus AI console (helm chart `practicus-console`), so add-on tokens minted by the console can
  be verified here. Same values used by the `practicus-mlflow` chart (`security.jwt.*`).
- `PRT_ADDON_KEY`: must match the "Service key" chosen when registering this Airflow service in the
  Practicus AI console (step 2 of `03_setup_sso.md`).
- `airflow.jwtSecretName` (recommended over the default `jwtSecret: ~`): pin the secret used to sign
  Airflow API JWTs so tokens survive `helm upgrade`. Without this, the chart generates a new random
  secret on every install/upgrade, invalidating every previously issued Airflow API token:
  ```shell
  kubectl create secret generic practicus-airflow-jwt-secret \
    --from-literal=jwt-secret="$(openssl rand -base64 32)" \
    -n <namespace>
  ```
  then set `airflow.jwtSecretName: practicus-airflow-jwt-secret` in `values.yaml`.
