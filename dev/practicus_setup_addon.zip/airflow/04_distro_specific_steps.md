Some Kubernetes distributions such as OpenShift will require additional steps to setup.
Please check the 'distro' folder for these additional steps.