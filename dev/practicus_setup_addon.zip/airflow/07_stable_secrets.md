# Stable Airflow encryption and signing keys

The Practicus Airflow chart now manages release-scoped Kubernetes Secrets by default:

| Secret | Data key | Purpose |
| --- | --- | --- |
| `<release>-fernet-key-stable` | `fernet-key` | Variables and Connection passwords/extra |
| `<release>-jwt-secret-stable` | `jwt-secret` | Airflow 3 API tokens |
| `<release>-api-secret-key-stable` | `api-secret-key` | Airflow 3 UI sessions |
| `<release>-webserver-secret-key-stable` | `webserver-secret-key` | Airflow 2 sessions (only on Airflow 2) |

They are normal Helm resources annotated `helm.sh/resource-policy: keep`, not install hooks.
Connected Helm installs/upgrades use `lookup` to reuse existing values. Uninstall leaves them
in place and reinstalling the same release in the same namespace reuses them. Multiple releases
get independent keys. Deleting the namespace still deletes its Secrets.

Fresh installs generate a proper Fernet key and signing/session secrets from 64 random bytes.
Changing an inline key value does not rotate an existing managed Secret: existing values win.

## Upgrade an existing deployment

1. Back up the metadata database and current key Secrets to your normal protected backup store.
2. Upgrade **before uninstalling** the old chart. Keep the release name, namespace and naming
   overrides unchanged. The chart copies the old upstream `<airflow-fullname>-fernet-key`,
   `-jwt-secret`, and `-api-secret-key` into the new stable Secrets when they exist.
   This preserves existing encrypted data, tokens and sessions. A missing Fernet key blocks an
   upgrade rather than generating a replacement.
3. If you already set an explicit `airflow.*SecretName`, that Secret remains externally managed
   and is used unchanged. Preserve it across reinstalls. To move it to the chart's stable default,
   first copy its data to the corresponding stable Secret and add the Helm ownership annotations
   for this release; then remove the explicit name override. Do not generate a replacement key.
4. Verify all Airflow components use the expected Secret and that existing Variables/Connections
   can be read. Back up the new stable Secrets with the database.

The `re_install` scripts now refresh with `helm upgrade --install`; they no longer uninstall first.
AWS operator scripts use the local chart, including these changes. Customer setup scripts use
the published chart: publish the updated chart before distributing those scripts.

## External Secrets and offline/GitOps rendering

To manage keys outside Helm, pre-create Secrets and set explicit names for all applicable keys:

```yaml
practicus:
  manageSecrets: false
airflow:
  fernetKeySecretName: company-airflow-fernet
  jwtSecretName: company-airflow-jwt
  apiSecretKeySecretName: company-airflow-api
```

Use the data keys from the table. For Airflow 2, configure `webserverSecretKeySecretName` instead
of the Airflow 3 keys. Kubernetes `data` values are base64 encoded; `stringData` accepts raw values.
Base64 encoding is not encryption. Back up keys in a secret manager, outside the namespace.

`helm template` and client dry runs cannot look up live Secrets: they generate throwaway values
for a fresh install. Never apply those generated Secret manifests to an existing database.
Use `helm upgrade --dry-run=server --hide-secret` for connected validation. GitOps renderers must
use externally managed Secrets and `practicus.manageSecrets: false`.
Empty/null Secret names are rejected while `manageSecrets` is enabled. Disabling management and
clearing those names opts back into the upstream chart's rotating defaults and should be avoided.

## Rotation and recovery

- **Fernet:** snapshot the database and keys; pause writes/tasks during the change. Set the
  Secret's raw value to `NEW_KEY,OLD_KEY` (include all historical keys still in use), restart all
  Airflow components, run `airflow rotate-fernet-key` once, and verify all encrypted fields.
  Remove old keys only after successful verification, then restart components again.
  A new key alone cannot repair existing ciphertext. If the previous key is unavailable, restore
  affected values from their source of truth; preserve corrupted rows before replacing them.
- **JWT/API:** migrated legacy keys are intentionally preserved, even if short. Replace a short
  JWT key with at least 64 random bytes (for example `openssl rand -base64 64 | tr -d '\n'`) and
  restart all components together. This invalidates previously issued tokens; API key rotation
  also ends UI sessions. Plan around active tasks because execution API tokens may be affected.
- Referenced Secrets are injected as environment variables. After any deliberate key rotation,
  explicitly restart Deployments/StatefulSets and any independently running task pods.
