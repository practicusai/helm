#!/bin/bash
set -eo pipefail

cd "$(dirname "$0")" || exit

# Refresh in place: the external metadata database and encryption keys must stay together.
bash ./11_install.sh

echo "Completed refreshing Airflow in place"
