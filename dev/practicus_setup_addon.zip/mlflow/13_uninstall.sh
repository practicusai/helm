#!/bin/bash

DEFAULT_SVC_NAME=practicus-mlflow
DEFAULT_SVC_NAMESPACE=prt-ns-mlflow

if [ -z "$PRT_SVC_NAME" ]; then
    export PRT_SVC_NAME=$DEFAULT_SVC_NAME
    echo "PRT_SVC_NAME env variable is not defined, will use the default $PRT_SVC_NAME"
fi

if [ -z "$PRT_SVC_NAMESPACE" ]; then
    export PRT_SVC_NAMESPACE=$DEFAULT_SVC_NAMESPACE
    echo "PRT_SVC_NAMESPACE env variable is not defined, will use the default $PRT_SVC_NAMESPACE"
fi

echo "Uninstalling $PRT_SVC_NAME"
helm uninstall "$PRT_SVC_NAME" \
  --namespace "$PRT_SVC_NAMESPACE" \
  --no-hooks || echo "No current installation found"

echo "Completed uninstalling $PRT_SVC_NAME"
