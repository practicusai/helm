# How to restore data 

Please view `prt-cnt-gitea-backup` container /README.md file for steps.
