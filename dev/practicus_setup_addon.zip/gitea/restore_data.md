# How to restore data 

Please view `prt-cnt-gitea-backup` container /READ_ME.md file for steps