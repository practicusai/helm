#!/bin/bash

# The below code is needed until the below issue is resolved
# https://gitea.com/gitea/helm-chart/issues/768

SVC_NAME=practicus-gitea
SVC_NAMESPACE=prt-ns-gitea

STATEFULSET_NAME="$SVC_NAME-act-runner"

# ** Add your replica count below **
REPLICA_COUNT=

if [ -z "${REPLICA_COUNT}" ]; then
  echo "ERROR: REPLICA_COUNT is not defined."
  exit 1
fi

echo "Updating statefulset replicas for namespace $SVC_NAMESPACE to $REPLICA_COUNT"

kubectl -n "$SVC_NAMESPACE" scale statefulset "$STATEFULSET_NAME" --replicas="$REPLICA_COUNT"

echo "*** Completed update ***"
