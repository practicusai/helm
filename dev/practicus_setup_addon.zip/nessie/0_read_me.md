# Notes

## Nessie sample catalog

- Create a schema

```sql
CREATE SCHEMA lakehouse.default WITH ( LOCATION = 's3a://lakehouse/default/' )
```

- Create a table

```sql
CREATE TABLE lakehouse.default.example_table (
    c1 INTEGER,
    c2 DATE,
    c3 DOUBLE
)
WITH (
    format = 'PARQUET',
    location = 's3a://lakehouse/default/example_table/'
);
```

- Insert some data

```sql
INSERT INTO lakehouse.default.example_table (c1, c2, c3)
VALUES 
    (11, DATE '2024-05-29', 3.14),
    (21, DATE '2024-05-30', 2.71),
    (31, DATE '2024-05-31', 1.41),
    -- Add more rows here
    (1001, DATE '2024-08-06', 3.58),
    (1011, DATE '2024-08-07', 2.99);

SELECT * from lakehouse.default.example_table
```
