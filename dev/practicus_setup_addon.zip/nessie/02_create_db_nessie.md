# Creating a database PostgreSQL database using pgAdmin

- This guide will help you create a PostgreSQL database require for your service
- We will be using pgAdmin, burt any other database management tool will be enough.

## Connect to Server  

- Connect to your database using pgAdmin tool.
- Note: If your database is in Kubernetes you will have to open a network tunnel to your computer first. Please see below of this file to learn how.

### Option 1) Creating Login and DB using GUI

- Right-click your database server, Create > login > select a name e.g. "prt_nessie_user"
  - Definition > select a secure password
  - Privileges > grant login permission.
- Right-click the server, Create > Database > select a name e.g 'prt_nessie', leave owner default
  - Security > Privileges > click "+" to add > Select "prt_nessie_user" as Grantee and select All privileges.

### Option 2) Creating Login and DB using SQL

- *IF* you have a PSQL enabled for remote server, you can use the below to create the database.

```sql

-- DROP ROLE IF EXISTS prt_nessie_user;

CREATE ROLE prt_nessie_user WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION
  PASSWORD '**** add your password here ****';

-- DROP DATABASE IF EXISTS prt_nessie;

CREATE DATABASE prt_nessie
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

GRANT ALL ON DATABASE prt_nessie TO prt_nessie_user;

```

### Grant permission to schema

- Right-click the newly created "prt_nessie" database > Query Tool
- Run the below SQL

```sql
GRANT ALL ON SCHEMA public TO prt_nessie_user;
```

### Updates values.yaml

Update values.yaml with the new database name user and password information.

### Appendix

#### Opening a tunnel for your db on Kubernetes

- If you installed the database server using practicus-pg-db helm chart with default values, you can use the below to open tunnel and connect the db from your computer  

```shell
echo "Starting temporary connection tunnel"
kubectl -n prt-ns port-forward service/prt-db-pg-1-rw 5432:5432
```
