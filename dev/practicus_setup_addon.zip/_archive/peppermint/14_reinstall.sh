#!/bin/bash

cd "$(dirname "$0")" || echo "Could not change directory to script location"

bash ./13_uninstall.sh
bash ./11_install.sh

echo "Completed reinstalling"
