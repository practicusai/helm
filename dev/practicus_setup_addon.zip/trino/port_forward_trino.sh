#!/bin/bash

SVC_NAME=practicus-trino
SVC_NAMESPACE=prt-ns-trino

# kubectl port-forward svc/$SVC_NAME 8080:8080 -n $SVC_NAMESPACE

kubectl port-forward svc/$SVC_NAME 8443:8443 -n $SVC_NAMESPACE
