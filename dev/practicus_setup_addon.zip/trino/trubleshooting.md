# Troubleshooting

## Trino certificate issues

### Conflicting CA

- While connecting to Trino from a Practicus AI system such as Worker or App, if you get `SSL: CERTIFICATE_VERIFY_FAILED certificate verify failed: self-signed certificate in certificate chain` error, please make sure you do not have a conflicting CA certificate on the Kubernetes pod.
- While installing Practicus AI console, an admin can set .Values.certificateAuthority.enabled = True, and provide the CA certificate. This will then get embedded to Practicus AI workers, apps etc. If this certificate conflicts with the verify="ca_cert.pem", Trino client can still use the CA certificate embedded into the pod, instead of the manually provided one.
- If this is the case, please make sure the same CA is used for both Console installation and Trino.
