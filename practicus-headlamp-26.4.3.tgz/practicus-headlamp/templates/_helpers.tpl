{{/*
Create the child chart context required by the upstream Headlamp fullname helper.
The parent chart's templates otherwise pass the parent Chart and Values objects.
*/}}
{{- define "practicus-headlamp.fullname" -}}
{{- $headlampContext := dict "Chart" (dict "Name" "headlamp") "Values" (.Values.headlamp | default dict) "Release" .Release -}}
{{- include "headlamp.fullname" $headlampContext -}}
{{- end -}}
