{{/* The upstream chart does not tpl Secret names. Resolve release-scoped defaults here. */}}
{{- define "fernet_key_secret" -}}
{{- tpl (default (printf "%s-fernet-key" (include "airflow.fullname" .)) .Values.fernetKeySecretName) . -}}
{{- end -}}

{{- define "jwt_secret" -}}
{{- tpl (default (printf "%s-jwt-secret" (include "airflow.fullname" .)) .Values.jwtSecretName) . -}}
{{- end -}}

{{- define "api_secret_key_secret" -}}
{{- tpl (default (printf "%s-api-secret-key" (include "airflow.fullname" .)) .Values.apiSecretKeySecretName) . -}}
{{- end -}}

{{- define "webserver_secret_key_secret" -}}
{{- tpl (default (printf "%s-webserver-secret-key" (include "airflow.fullname" .)) .Values.webserverSecretKeySecretName) . -}}
{{- end -}}
