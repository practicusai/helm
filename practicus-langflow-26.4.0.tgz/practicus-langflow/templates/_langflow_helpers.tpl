# Configurations specific to langflow

{{- define "addonSpecificConfigMap" }}
{{- $userConfig := .Values.additionalEnv }}

{{- if not (hasKey $userConfig "LANGFLOW_CONFIG_DIR") }}
  LANGFLOW_CONFIG_DIR: "/tmp/langflow"
{{- end }}
{{- if not (hasKey $userConfig "LANGFLOW_LOG_FILE") }}
  LANGFLOW_LOG_FILE: "/tmp/langflow.log"
{{- end }}
{{- if not (hasKey $userConfig "LANGFLOW_ALEMBIC_LOG_FILE") }}
  LANGFLOW_ALEMBIC_LOG_FILE: "/tmp/alembic.log"
{{- end }}

{{- if .Values.main.logLevel }}
  LANGFLOW_LOG_LEVEL: {{ quote .Values.main.logLevel }}
{{- end }}

{{- if .Values.security.user.impersonate }}
  PRT_PRIMARY_PROTOCOL: {{ quote .Values.security.user.protocol }}
  PRT_K8S_HOSTS: {{ quote .Values.security.user.host }}
  PRT_USER_EMAIL: {{ quote .Values.security.user.email }}
{{- end }}

{{- if .Values.advanced.optimizeForOffline }}
  LANGFLOW_CREATE_STARTER_PROJECTS: "false"
  LANGFLOW_UPDATE_STARTER_PROJECTS: "false"
  LANGFLOW_EVENT_DELIVERY: "direct"
  NVIDIA_API_KEY: ""
{{- end }}

{{- end }}

{{- define "addonSpecificSecret" }}

{{- if .Values.security.user.impersonate }}
  PRT_API_TOKEN: {{ b64enc .Values.security.user.refresh_token }}
{{- end }}

{{- end }}
